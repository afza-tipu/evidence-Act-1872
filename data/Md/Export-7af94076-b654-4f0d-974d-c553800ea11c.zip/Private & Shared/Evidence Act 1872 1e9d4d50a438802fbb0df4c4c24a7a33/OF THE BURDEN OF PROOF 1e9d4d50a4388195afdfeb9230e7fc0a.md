# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-111
Section_Number: 111
Section_Title: Proof of good faith in transactions where one party is in relation of active confidence
Status: Active
Tags: Burden of Proof, Good Faith, Active Confidence
Section_Text: 111. Where there is a question as to the good faith of a transaction between parties, one of whom stands to the other in a position of active confidence, the burden of proving the good faith of the transaction is on the party who is in a position of active confidence.\n\nIllustrations\n\n(a) The good faith of a sale by a client to an attorney is in question in a suit brought by the client. The burden of proving the good faith of the transaction is on the attorney.\n\n(b) The good faith of a sale by a son just come of age to a father is in question in a suit brought by the son. The burden of proving the good faith of the transaction is on the father.
Illustrations: ILLUS: (a) The good faith of a sale by a client to an attorney is in question in a suit brought by the client. The burden of proving the good faith of the transaction is on the attorney.\nILLUS: (b) The good faith of a sale by a son just come of age to a father is in question in a suit brought by the son. The burden of proving the good faith of the transaction is on the father.