# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-130
Section_Number: 130
Section_Title: Production of title-deed of witness, not a party
Status: Active
Tags: Witness Rule, Privilege, Production of Document, Title Deed
Section_Text: 130. No witness who is not a party to a suit shall be compelled to produce his title-deeds to any property or any document in virtue of which he holds any property as pledgee or mortgagee or any document the production of which might tend to criminate him, unless he has agreed in writing to produce them with the person seeking the production of such deeds or some person through whom he claims.
Cross_References: sec-165 (Privilege referred to in S.165)