# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-112
Section_Number: 112
Section_Title: Birth during marriage conclusive proof of legitimacy
Status: Active
Tags: Conclusive Proof, Legitimacy, Marriage, Access
Section_Text: 112. The fact that any person was born during the continuance of a valid marriage between his mother and any man, or within two hundred and eighty days after its dissolution, the mother remaining unmarried, shall be conclusive proof that he is the legitimate son of that man, unless it can be shown that the parties to the marriage had no access to each other at any time when he could have been begotten.
Cross_References: sec-4 (Uses term 'conclusive proof' defined in S.4)