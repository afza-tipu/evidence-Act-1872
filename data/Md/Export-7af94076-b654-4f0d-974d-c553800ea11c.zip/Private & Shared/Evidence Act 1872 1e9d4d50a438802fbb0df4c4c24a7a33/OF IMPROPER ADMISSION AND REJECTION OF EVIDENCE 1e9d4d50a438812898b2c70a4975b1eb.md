# OF IMPROPER ADMISSION AND REJECTION OF EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: XI
Section_ID: sec-167
Section_Number: 167
Section_Title: No new trial for improper admission or rejection of evidence
Status: Active
Tags: Rule of Evidence, Procedure, Improper Admission, Improper Rejection, New Trial
Section_Text: 167. The improper admission or rejection of evidence shall not be ground of itself for a new trail or reversal of any decision in any case, if it shall appear to the Court before which such objection is raised that, independently of the evidence objected to and admitted, there was sufficient evidence to justify the decision, or that, if the rejected evidence had been received, it ought not to have varied the decision.