# PUBLIC DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-78
Section_Number: 78
Section_Title: Proof of other official documents
Status: Active
Tags: Documentary Evidence Rule, Proof, Official Document
Section_Text: 78. The following public documents may be proved as follows:–\n\n⁴⁹[(1) Acts, orders or notifications of the Government or any other Government that functioned within the territories now comprised in Bangladesh or any departments thereof by the records of the departments, certified by the heads of those departments, or by any document purporting to be printed by order of any such Government:]\n\n(2) the proceeding of the ⁵⁰[Parliament and of any legislature which had power to legislate in respect of territories now comprised in Bangladesh,] by the journals of those bodies respectively, or by published Acts or abstracts, or by copies purporting to be printed by order of the Government ⁵¹[* * *]:\n\n(3) [Omitted by section 3 and 2nd Schedule of the Bangladesh Laws (Revision And Declaration) Act, 1973 (Act No. VIII of 1973).]\n\n(4) the Acts of the Executive or the proceedings of the Legislature of a foreign country, - by journals published by their authority, or commonly received in that country as such, or by a copy certified under the seal of the country or sovereign, or by a recognition thereof in some ⁵²[Act of Parliament]:\n\n(5) the proceedings, of a municipal body in Bangladesh,\n\nby a copy of such proceedings, certified by the legal keeper thereof, or by a printed book purporting to be published by the authority of such body:\n\n(6) public documents of any other class in a foreign country,–\n\nby the original, or by a copy certified by the legal keeper thereof, with a certificate under the seal of a notary public, or of a Bangladesh Consul or diplomatic agent, that the copy is duly certified by the officer having the legal custody of the original, and upon proof of the character of the document according to the law of the foreign country.
Explanations: EXPL: [Omitted by section 3 and 2nd Schedule of the Bangladesh Laws (Revision And Declaration) Act, 1973 (Act No. VIII of 1973)].
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Omission by Bangladesh Laws (Revision And Declaration) Act, 1973;; Omission by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973