# PUBLIC DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-76
Section_Number: 76
Section_Title: Certified copies of public documents
Status: Active
Tags: Public Document, Certified Copy
Section_Text: 76. Every public officer having the custody of a public document, which any person has a right to inspect, shall give that person on demand a copy of it on payment of the legal fees therefor, together with a certificate written at the foot of such copy that it is a true copy of such document or part thereof, as the case may be, and such certificate shall be dated and subscribed by such officer with his name and his official title, and shall be sealed, whenever such officer is authorized by law to make use of a seal, and such copies so certified shall be called certified copies.\n\nExplanation.-Any officer who, by the ordinary course of official duty, is authorized to deliver such copies, shall be deemed to have the custody of such documents within the meaning of this section.
Explanations: EXPL: Any officer who, by the ordinary course of official duty, is authorized to deliver such copies, shall be deemed to have the custody of such documents within the meaning of this section.
Cross_References: sec-77 (Referenced by S.77);; sec-79 (Relates to presumption under S.79)