# CHARACTER WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-55
Section_Number: 55
Section_Title: Character as affecting damages
Status: Active
Tags: Character Evidence, Civil Cases, Damages, Definition
Section_Text: 55. In civil cases the fact that the character of any person is such as to affect the amount of damages which he ought to receive, is relevant.\n\nExplanation.–In sections 52, 53, 54 and 55, the word "character" includes both reputation and disposition; but, except as provided in section 54, evidence may be given only of general reputation and general disposition, and not of particular acts by which reputation or disposition were shown.
Explanations: EXPL: In sections 52, 53, 54 and 55, the word "character" includes both reputation and disposition; but, except as provided in section 54, evidence may be given only of general reputation and general disposition, and not of particular acts by which reputation or disposition were shown.
Cross_References: sec-52 (Explanation defines character for S.52);; sec-53 (Explanation defines character for S.53);; sec-54 (Explanation defines character for S.54)