# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-65
Section_Number: 65
Section_Title: Cases in which secondary evidence relating to documents may be given
Status: Active
Tags: Documentary Evidence Rule, Secondary Evidence, Exceptions
Section_Text: 65. Secondary evidence may be given of the existence, condition or contents of a document in the following cases:–\n\n(a) when the original is shown or appears to be in the possession or power-\n\nof the person against whom the document is sought to be proved, or of any person out of reach of, or not subject to, the process of the Court, or\n\nof any person legally bound to produce it, and when, after the notice mentioned in section 66, such person does not produce it;\n\n(b) when the existence, condition or contents of the original have been proved to be admitted in writing by the person against whom it is proved or by his representative in interest;\n\n(c) when the original has been destroyed or lost, or when the party offering evidence of its contents cannot, for any other reason not arising from his own default or neglect, produce it in reasonable time;\n\n(d) when the original is of such a nature as not to be easily moveable;\n\n(e) when the original is a public document within the meaning of section 74;\n\n(f) when the original is a document of which a certified copy is permitted by this Act, or by any other law in force in Bangladesh to be given in evidence;\n\n(g) when the originals consist of numerous accounts or other documents which cannot conveniently be examined in Court, and the fact to be proved is the general result of the whole collection.\n\nIn cases (a), (c), and (d), any secondary evidence of the contents of the document is admissible.\n\nIn case (b), the written admission is admissible.\n\nIn case (e) or (f), a certified copy of the document, but no other kind of secondary evidence, is admissible.\n\nIn case (g), evidence may be given as to the general result of the documents by any person who has examined them, and who is skilled in the examination of such documents.
Cross_References: sec-64 (Exceptions to S.64);; sec-66 (Clause (a) refers to notice under S.66);; sec-74 (Clause (e) refers to S.74)