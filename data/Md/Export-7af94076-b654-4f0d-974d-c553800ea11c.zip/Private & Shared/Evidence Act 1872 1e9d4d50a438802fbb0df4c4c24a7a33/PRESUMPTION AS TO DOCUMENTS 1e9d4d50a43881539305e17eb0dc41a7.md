# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-89
Section_Number: 89
Section_Title: Presumption as to due execution, etc., of documents not produced
Status: Active
Tags: Presumption, Shall Presume, Notice to Produce
Section_Text: 89. The Court shall presume that every document, called for and not produced after notice to produce, was attested, stamped and executed in the manner required by law.
Cross_References: sec-66 (Relates to notice under S.66)