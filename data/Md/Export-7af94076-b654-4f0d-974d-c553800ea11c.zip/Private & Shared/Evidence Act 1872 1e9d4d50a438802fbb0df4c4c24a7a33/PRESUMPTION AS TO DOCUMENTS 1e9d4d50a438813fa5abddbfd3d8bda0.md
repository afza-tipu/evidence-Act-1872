# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-90
Section_Number: 90
Section_Title: Presumption as to documents thirty years old
Status: Active
Tags: Presumption, May Presume, Ancient Document, Proper Custody
Section_Text: 90. Where any document, purporting or proved to be thirty years old, is produced from any custody which the Court in the particular case considers proper, the Court may presume that the signature and every other part of such document, which purports to be in the handwriting of any particular person, is in that person's handwriting, and, in the case of a document executed or attested, that it was duly executed and attested by the persons by whom it purports to be executed and attested.\n\nExplanation.-Documents are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they would naturally be; but no custody is improper if it is proved to have had a legitimate origin, or if the circumstances of the particular case are such as to render such an origin probable.\n\nThis explanation applies also to section 81.\n\nIllustrations\n\n(a) A has been in possession of landed property for a long time. He produces from his custody deeds relating to the land, showing his titles to it. The custody is proper.\n\n(b) A produces deeds relating to landed property of which he is the mortgagee. The mortgagor is in possession. The custody is proper.\n\n(c) A, a connection of B, produces deeds relating to lands in B's possession which were deposited with him by B for safe custody. The custody is proper.
Explanations: EXPL: Documents are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they would naturally be; but no custody is improper if it is proved to have had a legitimate origin, or if the circumstances of the particular case are such as to render such an origin probable.\n\nThis explanation applies also to section 81.
Illustrations: ILLUS: (a) A has been in possession of landed property for a long time. He produces from his custody deeds relating to the land, showing his titles to it. The custody is proper.\nILLUS: (b) A produces deeds relating to landed property of which he is the mortgagee. The mortgagor is in possession. The custody is proper.\nILLUS: (c) A, a connection of B, produces deeds relating to lands in B's possession which were deposited with him by B for safe custody. The custody is proper.
Cross_References: sec-81 (Explanation applies to S.81)