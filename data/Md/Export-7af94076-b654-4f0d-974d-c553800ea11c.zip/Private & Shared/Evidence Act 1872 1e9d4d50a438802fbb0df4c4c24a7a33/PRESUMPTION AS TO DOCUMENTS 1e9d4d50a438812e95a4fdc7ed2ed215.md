# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-89A
Section_Number: 89A
Section_Title: Presumption as to physical or forensic evidence
Status: Active
Tags: Presumption, May Presume, Physical Evidence, Forensic Evidence
Section_Text: ⁶¹[89A. The Court may presume unless contrary is proved that the physical or forensic evidence belongs to or is created by that person from whom it purports to have been collected.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-73B (Relates to comparison under S.73B)