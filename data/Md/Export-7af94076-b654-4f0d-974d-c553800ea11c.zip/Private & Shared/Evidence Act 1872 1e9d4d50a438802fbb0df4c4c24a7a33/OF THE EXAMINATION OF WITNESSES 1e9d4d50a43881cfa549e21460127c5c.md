# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-161
Section_Number: 161
Section_Title: Right of adverse party as to writing used to refresh memory
Status: Active
Tags: Witness Examination, Refreshing Memory, Cross-examination
Section_Text: 161. Any writing referred to under the provisions of the two last preceding sections must be produced and shown to the adverse party if he requires it: such party may, if he pleases, cross-examine the witness thereupon.
Cross_References: sec-159 (Refers to provisions under S.159);; sec-160 (Refers to provisions under S.160)