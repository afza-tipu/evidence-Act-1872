# PUBLIC DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-75
Section_Number: 75
Section_Title: Private documents
Status: Active
Tags: Definition, Private Document
Section_Text: 75. All other documents are private.