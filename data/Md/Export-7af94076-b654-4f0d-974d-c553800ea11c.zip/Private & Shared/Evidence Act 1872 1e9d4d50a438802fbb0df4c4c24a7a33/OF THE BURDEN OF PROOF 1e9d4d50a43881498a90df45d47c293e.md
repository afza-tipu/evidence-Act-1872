# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-102
Section_Number: 102
Section_Title: On whom burden of proof lies
Status: Active
Tags: Burden of Proof
Section_Text: 102. The burden of proof in a suit or proceeding lies on that person who would fail if no evidence at all were given on either side.\n\nIllustrations\n\n(a) A sues B for land of which B is in possession, and which, as A asserts, was left to A by the will of C, B's father.\n\nIf no evidence were given on either side, B would be entitled to retain his possession.\n\nTherefore the burden of proof is on A.\n\n(b) A sues B for money due on a bond.\n\nThe execution of the bond is admitted, but B says that it was obtained by fraud, which A denies.\n\nIf no evidence were given on either side, A would succeed as the bond is not disputed and the fraud is not proved.\n\nTherefore the burden of proof is on B.
Illustrations: ILLUS: (a) A sues B for land of which B is in possession, and which, as A asserts, was left to A by the will of C, B's father.\n\nIf no evidence were given on either side, B would be entitled to retain his possession.\n\nTherefore the burden of proof is on A.\nILLUS: (b) A sues B for money due on a bond.\n\nThe execution of the bond is admitted, but B says that it was obtained by fraud, which A denies.\n\nIf no evidence were given on either side, A would succeed as the bond is not disputed and the fraud is not proved.\n\nTherefore the burden of proof is on B.