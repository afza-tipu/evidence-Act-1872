# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-103
Section_Number: 103
Section_Title: Burden of proof as to particular fact
Status: Active
Tags: Burden of Proof, Particular Fact
Section_Text: 103. The burden of proof as to any particular fact lies on that person who wishes the Court to believe in its existence, unless it is provided by any law that the proof of that fact shall lie on any particular person.\n\nIllustration\n\n(a) A prosecutes B for theft, and wishes the Court to believe that B admitted the theft to C. A must prove the admission.\n\nB wishes the Court to believe that, at the time in question, he was elsewhere. He must prove it.
Illustrations: ILLUS: (a) A prosecutes B for theft, and wishes the Court to believe that B admitted the theft to C. A must prove the admission.\n\nB wishes the Court to believe that, at the time in question, he was elsewhere. He must prove it.