# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-47
Section_Number: 47
Section_Title: Opinion as to handwriting, when relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Handwriting
Section_Text: 47. When the Court has to form an opinion as to the person by whom any document was written or signed, the opinion of any person acquainted with the handwriting of the person by whom it is supposed to be written or signed that it was or was not written or signed by that person, is a relevant fact.\n\nExplanation.–A person is said to be acquainted with the handwriting of another person when he has seen that person write, or when he has received documents purporting to be written by that person in answer to documents written by himself or under his authority and addressed to that person, or when, in the ordinary course of business, documents purporting to be written by that person have been habitually submitted to him.\n\nIllustration\n\nThe question is, whether a given letter is in the handwriting of A, a merchant in London.\n\nB is a merchant in Chittagong, who has written letters addressed to A and received letters purporting to be written by him. C is B's clerk, whose duty it was to examine and file B's correspondence. D is B's broker, to whom B habitually submitted the letters purporting to be written by A for the purpose of advising with him thereon.\n\nThe opinions of B, C and D on the question whether the letter is in the handwriting of A are relevant, though neither B, C or D ever saw A write.
Explanations: EXPL: A person is said to be acquainted with the handwriting of another person when he has seen that person write, or when he has received documents purporting to be written by that person in answer to documents written by himself or under his authority and addressed to that person, or when, in the ordinary course of business, documents purporting to be written by that person have been habitually submitted to him.
Illustrations: ILLUS: The question is, whether a given letter is in the handwriting of A, a merchant in London.\n\nB is a merchant in Chittagong, who has written letters addressed to A and received letters purporting to be written by him. C is B's clerk, whose duty it was to examine and file B's correspondence. D is B's broker, to whom B habitually submitted the letters purporting to be written by A for the purpose of advising with him thereon.\n\nThe opinions of B, C and D on the question whether the letter is in the handwriting of A are relevant, though neither B, C or D ever saw A write.