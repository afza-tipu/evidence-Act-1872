# JUDGMENTS OF COURTS OF JUSTICE WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-42
Section_Number: 42
Section_Title: Relevancy and effect of judgments, orders or decrees, other than those mentioned in section 41
Status: Active
Tags: Relevancy, Judgment, Public Nature
Section_Text: 42. Judgments, orders or decrees other than those mentioned in section 41 are relevant if they relate to matters of a public nature relevant to the inquiry; but such judgments, orders or decrees are not conclusive proof of that which they state.\n\nIllustration\n\nA sues B for trespass on his land. B alleges the existence of a public right of way over the land, which A denies.\n\nThe existence of a decree in favour of the defendant, in a suit by A against C for a trespass on the same land, in which C alleged the existence of the same right of way, is relevant, but it is not conclusive proof that the right of way exists.
Illustrations: ILLUS: A sues B for trespass on his land. B alleges the existence of a public right of way over the land, which A denies.\n\nThe existence of a decree in favour of the defendant, in a suit by A against C for a trespass on the same land, in which C alleged the existence of the same right of way, is relevant, but it is not conclusive proof that the right of way exists.
Cross_References: sec-41 (Excludes judgments mentioned in S.41);; sec-43 (Referenced by S.43);; sec-44 (Referenced by S.44)