# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-7
Section_Number: 7
Section_Title: Facts which are the occasion cause or effect of facts in issue
Status: Active
Tags: Relevancy Rule, Occasion, Cause, Effect, Opportunity
Section_Text: 7. Facts which are the occasions, cause or effect, immediate or otherwise, of relevant facts, or facts in issue, or which constitute the state of things under which they happened, or which afforded an opportunity for their occurrence or transaction, are relevant.\n\nIllustrations\n\n(a) The question is, whether A robbed B.\n\nThe facts that, shortly before the robbery, B went to a fair with money in his possession, and that he showed it or mentioned the fact that he had it, to third persons, are relevant.\n\n(b) The question is, whether A murdered B.\n\nMarks on the ground, produced by a struggle at or near the place where the murder was committed, are relevant facts.\n\n(c) The question is, whether A poisoned B.\n\nThe state of B's health before the symptoms ascribed to poison, and habits of B, known to A, which afforded an opportunity for the administration of poison, are relevant facts.
Illustrations: ILLUS: (a) The question is, whether A robbed B.\n\nThe facts that, shortly before the robbery, B went to a fair with money in his possession, and that he showed it or mentioned the fact that he had it, to third persons, are relevant.\nILLUS: (b) The question is, whether A murdered B.\n\nMarks on the ground, produced by a struggle at or near the place where the murder was committed, are relevant facts.\nILLUS: (c) The question is, whether A poisoned B.\n\nThe state of B's health before the symptoms ascribed to poison, and habits of B, known to A, which afforded an opportunity for the administration of poison, are relevant facts.