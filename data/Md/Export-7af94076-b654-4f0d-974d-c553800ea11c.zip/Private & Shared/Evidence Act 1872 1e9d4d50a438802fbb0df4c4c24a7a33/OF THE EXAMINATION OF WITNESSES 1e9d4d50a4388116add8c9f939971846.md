# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-144
Section_Number: 144
Section_Title: Evidence as to matters in writing
Status: Active
Tags: Witness Examination, Documentary Evidence, Oral Evidence
Section_Text: 144. Any witness may be asked, whilst under examination, whether any contract, grant or other disposition of property, as to which he is giving evidence, was not contained in a document, and if he says that it was, or if he is about to make any statement as to the contents of any document, which in the opinion of the Court, ought to be produced, the adverse party may object to such evidence being given until such document is produced, or until facts have been proved which entitle the party who called the witness to give secondary evidence of it.\n\nExplanation.– A witness may give oral evidence of statements made by other persons about the contents of documents if such statements are in themselves relevant facts.\n\nIllustration\n\nThe question is, whether A assaulted B.\n\nC deposes that he heard A says to D-\"B wrote a letter accusing me of theft, and I will be revenged on him." This statement is relevant, as showing A's motive for the assault, and evidence may be given of it, though no other evidence is given about the letter.
Explanations: EXPL: A witness may give oral evidence of statements made by other persons about the contents of documents if such statements are in themselves relevant facts.
Illustrations: ILLUS: The question is, whether A assaulted B.\n\nC deposes that he heard A says to D-\"B wrote a letter accusing me of theft, and I will be revenged on him." This statement is relevant, as showing A's motive for the assault, and evidence may be given of it, though no other evidence is given about the letter.