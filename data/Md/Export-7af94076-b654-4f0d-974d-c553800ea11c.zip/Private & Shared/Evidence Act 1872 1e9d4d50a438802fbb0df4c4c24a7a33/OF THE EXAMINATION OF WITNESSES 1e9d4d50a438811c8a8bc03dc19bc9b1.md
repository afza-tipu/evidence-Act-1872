# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-139
Section_Number: 139
Section_Title: Cross-examination of person called to produce a document
Status: Active
Tags: Witness Examination, Cross-examination, Production of Document
Section_Text: 139. A person summoned to produce a document does not become a witness by the mere fact that he produces it and cannot be cross-examined unless and until he is called as a witness.