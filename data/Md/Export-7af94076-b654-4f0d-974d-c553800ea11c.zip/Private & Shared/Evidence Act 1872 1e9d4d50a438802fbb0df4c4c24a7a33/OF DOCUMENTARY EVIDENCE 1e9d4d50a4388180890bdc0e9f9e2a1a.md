# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-61
Section_Number: 61
Section_Title: Proof of contents of documents
Status: Active
Tags: Documentary Evidence Rule, Proof
Section_Text: 61. The contents of documents may be proved either by primary or by secondary evidence.