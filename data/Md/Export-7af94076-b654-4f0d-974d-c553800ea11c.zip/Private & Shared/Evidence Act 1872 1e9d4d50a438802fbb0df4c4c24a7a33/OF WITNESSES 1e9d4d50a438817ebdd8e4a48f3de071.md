# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-129
Section_Number: 129
Section_Title: Confidential communications with legal advisers
Status: Active
Tags: Witness Rule, Privilege, Legal Professional Privilege, Client
Section_Text: 129. No one shall be compelled to disclose to the Court any confidential communication which has taken place between him and his legal professional adviser, unless he offers himself as a witness, in which case he may be compelled to disclose any such communications as may appear to the Court necessary to be known in order to explain any evidence which he has given, but no others.
Cross_References: sec-165 (Privilege referred to in S.165)