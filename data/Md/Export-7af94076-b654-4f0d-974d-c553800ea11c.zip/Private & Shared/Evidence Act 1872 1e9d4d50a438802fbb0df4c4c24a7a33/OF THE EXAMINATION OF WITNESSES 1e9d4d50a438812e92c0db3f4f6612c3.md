# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-145
Section_Number: 145
Section_Title: Cross-examination as to previous statements in writing
Status: Active
Tags: Witness Examination, Cross-examination, Previous Statement, Contradiction
Section_Text: 145. A witness may be cross-examined as to previous statements made by him in writing or reduced into writing, and relevant to matters in question, without such writing being shown to him, or being proved; but, if it is intended to contradict him by the writing, his attention must, before the writing can be proved, be called to those parts of it which are to be used for the purpose of contradicting him.
Cross_References: sec-155 (S.155(3) relates to this section)