# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-79
Section_Number: 79
Section_Title: Presumption as to genuineness of certified copies
Status: Active
Tags: Presumption, Shall Presume, Certified Copy
Section_Text: 79. The Court shall presume every document purporting to be a certificate, certified copy or other document, which is by law declared to be admissible as evidence of any particular fact and which purports to be duly certified by any officer of the ⁵³[Government] to be genuine:\n\nProvided that such document is substantially in the form and purports to be executed in the manner directed by law in that behalf.\n\nThe Court shall also presume that any officer by whom any such document purports to be signed or certified, held, when he signed it, the official character which he claims in such paper.
Provisos: PROV: Provided that such document is substantially in the form and purports to be executed in the manner directed by law in that behalf.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973
Cross_References: sec-76 (Relates to certified copies under S.76);; sec-77 (Relates to proof by certified copies under S.77)