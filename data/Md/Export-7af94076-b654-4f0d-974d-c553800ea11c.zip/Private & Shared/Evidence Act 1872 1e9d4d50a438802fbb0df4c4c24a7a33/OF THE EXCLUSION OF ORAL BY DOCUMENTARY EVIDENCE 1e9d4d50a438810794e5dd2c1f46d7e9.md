# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-96
Section_Number: 96
Section_Title: Evidence as to application of language which can apply to one only of several persons
Status: Active
Tags: Documentary Evidence Rule, Ambiguity, Latent Ambiguity, Equivocation
Section_Text: 96. When the facts are such that the language used might have been meant to apply to any one, and could not have been meant to apply to more than one, of several persons or things, evidence may be given of facts which show which of those persons or things it was intended to apply to.\n\nIllustrations\n\n(a) A agrees to sell to B, for Taka 1,000, "my white horse". A has two white horses. Evidence may be given of facts which show which of them was meant.\n\n(b) A agrees to accompany B to 67[Saidpur]. Evidence may be given of facts showing whether 68[Saidpur in Khulna or Saidpur in Rangpur] was meant.
Illustrations: ILLUS: (a) A agrees to sell to B, for Taka 1,000, "my white horse". A has two white horses. Evidence may be given of facts which show which of them was meant.\nILLUS: (b) A agrees to accompany B to 67[Saidpur]. Evidence may be given of facts showing whether 68[Saidpur in Khulna or Saidpur in Rangpur] was meant.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973