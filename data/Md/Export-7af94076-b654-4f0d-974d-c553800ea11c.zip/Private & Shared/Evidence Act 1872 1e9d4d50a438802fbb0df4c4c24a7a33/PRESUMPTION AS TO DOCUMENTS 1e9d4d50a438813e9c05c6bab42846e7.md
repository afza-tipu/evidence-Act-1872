# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-87
Section_Number: 87
Section_Title: Presumption as to books, maps and charts
Status: Active
Tags: Presumption, May Presume, Books, Maps, Charts
Section_Text: 87. The Court may presume that any book to which it may refer for information on matters of public or general interest, and that any published map or chart, the statements of which are relevant facts and which is produced for its inspection, was written and published by the person and at the time and place, by whom or at which it purports to have been written or published.
Cross_References: sec-36 (Relates to S.36)