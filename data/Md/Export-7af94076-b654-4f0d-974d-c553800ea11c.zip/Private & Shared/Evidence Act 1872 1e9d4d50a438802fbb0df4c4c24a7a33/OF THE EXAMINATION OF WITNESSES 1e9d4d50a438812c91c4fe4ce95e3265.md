# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-152
Section_Number: 152
Section_Title: Questions intended to insult or annoy
Status: Active
Tags: Witness Examination, Improper Question, Insult, Annoy
Section_Text: 152. The Court shall forbid any question which appears to it to be intended to insult or annoy, or which, though proper in itself, appears to the Court needlessly offensive in form.
Cross_References: sec-165 (Judge's power limited by this section)