# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-66
Section_Number: 66
Section_Title: Rules as to notice to produce
Status: Active
Tags: Documentary Evidence Rule, Notice to Produce, Secondary Evidence
Section_Text: 66. Secondary evidence of the contents of the documents referred to in section 65, clause (a), shall not be given unless the party proposing to give such secondary evidence has previously given to the party in whose possession or power the document is, or to his Advocate, such notice to produce it as is prescribed by law; and if no notice is prescribed by law, then such notice as the Court considers reasonable under the circumstances of the case:\n\nProvided that such notice shall not be required in order to render secondary evidence admissible in any of the following cases, or in any other case in which the Court thinks fit to dispense with it:–\n\n(1) when the document to be proved is itself a notice;\n\n(2) when, from the nature of the case, the adverse party must know that he will be required to produce it;\n\n(3) when it appears or is proved that the adverse party has obtained possession of the original by fraud or force;\n\n(4) when the adverse party or his agent has the original in Court;\n\n(5) when the adverse party or his agent has admitted the loss of the document;\n\n(6) when the person in possession of the document is out of reach of, or not subject to, the process of the Court.
Provisos: PROV: Provided that such notice shall not be required in order to render secondary evidence admissible in any of the following cases, or in any other case in which the Court thinks fit to dispense with it:–\n\n(1) when the document to be proved is itself a notice;\n\n(2) when, from the nature of the case, the adverse party must know that he will be required to produce it;\n\n(3) when it appears or is proved that the adverse party has obtained possession of the original by fraud or force;\n\n(4) when the adverse party or his agent has the original in Court;\n\n(5) when the adverse party or his agent has admitted the loss of the document;\n\n(6) when the person in possession of the document is out of reach of, or not subject to, the process of the Court.
Cross_References: sec-65 (Refers to S.65(a));; sec-89 (Relates to presumption under S.89)