# STATEMENTS MADE UNDER SPECIAL CIRCUMSTANCES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-38
Section_Number: 38
Section_Title: Relevancy of statements as to any law contained in law-books
Status: Active
Tags: Relevancy Rule, Foreign Law, Law Books
Section_Text: 38. When the Court has to form an opinion as to a law of any country, any statement of such law contained in a book purporting to be printed or published under the authority of the Government of such country and to contain any such law, and any report of a ruling of the Courts of such country contained in a book purporting to be a report of such rulings, is relevant.