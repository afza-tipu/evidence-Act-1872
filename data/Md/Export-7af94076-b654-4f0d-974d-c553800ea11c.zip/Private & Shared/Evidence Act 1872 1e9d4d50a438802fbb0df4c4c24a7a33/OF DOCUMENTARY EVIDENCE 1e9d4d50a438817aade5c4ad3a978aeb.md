# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-73
Section_Number: 73
Section_Title: Comparison of signature, writing or seal with others, admitted or proved
Status: Active
Tags: Documentary Evidence Rule, Proof, Comparison, Signature, Handwriting, Seal, Finger Impression
Section_Text: 73. In order to ascertain whether a signature, writing or seal is that of the person by whom it purports to have been written or made, any signature, writing or seal admitted or proved to the satisfaction of the Court to have been written or made by that person may be compared with the one which is to be proved, although that signature, writing or seal has not been produced or proved for any other purpose.\n\nThe Court may direct any person present in Court to write any words or figures for the purpose of enabling the Court to compare the words or figures so written with any words or figures alleged to have been written by such person.\n\nThis section applies also, with any necessary modifications, to finger-impressions.