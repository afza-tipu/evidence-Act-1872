# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-101
Section_Number: 101
Section_Title: Burden of proof
Status: Active
Tags: Burden of Proof
Section_Text: 101. Whoever desires any Court to give judgment as to any legal right or liability dependent on the existence of facts which he asserts, must prove that those facts exist.\n\nWhen a person is bound to prove the existence of any fact, it is said that the burden of proof lies on that person.\n\nIllustrations\n\n(a) A desires a Court to give judgment that B shall be punished for a crime which A says B has committed.\n\nA must prove that B has committed the crime.\n\n(b) A desires a Court to give judgment that he is entitled to certain land in the possession of B, by reason of facts which he asserts, and which B denies, to be true.\n\nA must prove the existence of those facts.
Illustrations: ILLUS: (a) A desires a Court to give judgment that B shall be punished for a crime which A says B has committed.\n\nA must prove that B has committed the crime.\nILLUS: (b) A desires a Court to give judgment that he is entitled to certain land in the possession of B, by reason of facts which he asserts, and which B denies, to be true.\n\nA must prove the existence of those facts.