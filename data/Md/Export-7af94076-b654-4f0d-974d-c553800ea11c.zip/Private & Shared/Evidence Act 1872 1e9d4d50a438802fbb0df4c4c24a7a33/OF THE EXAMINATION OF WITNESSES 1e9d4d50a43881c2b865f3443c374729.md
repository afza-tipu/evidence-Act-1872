# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-160
Section_Number: 160
Section_Title: Testimony to facts stated in document mentioned in section 159
Status: Active
Tags: Witness Examination, Refreshing Memory
Section_Text: 160. A witness may also testify to facts mentioned in any such document as is mentioned in section 159, although he has no specific recollection of the facts themselves, if he is sure that the facts were correctly recorded in the document.\n\nIllustration\n\nA book-keeper may testify to facts recorded by him in books regularly kept in the course of business, if he knows that the books were correctly kept, although he has forgotten the particular transactions entered.
Illustrations: ILLUS: A book-keeper may testify to facts recorded by him in books regularly kept in the course of business, if he knows that the books were correctly kept, although he has forgotten the particular transactions entered.
Cross_References: sec-159 (Refers to document under S.159);; sec-161 (Referenced by S.161)