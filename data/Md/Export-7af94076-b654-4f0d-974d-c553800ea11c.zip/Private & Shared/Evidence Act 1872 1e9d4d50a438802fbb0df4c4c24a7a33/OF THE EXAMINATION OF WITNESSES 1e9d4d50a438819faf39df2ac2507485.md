# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-150
Section_Number: 150
Section_Title: Procedure of Court in case of question being asked without reasonable grounds
Status: Active
Tags: Witness Examination, Procedure, Advocate Conduct
Section_Text: 150. If the Court is of opinion that any such question was asked without reasonable grounds, it may, if it was asked by any ⁸⁰[Advocate], report the circumstances of the case to the ⁸¹[High Court Division] or other authority to which such ⁸²[Advocate] is subject in the exercise of his profession.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973
Cross_References: sec-149 (Relates to violation of S.149)