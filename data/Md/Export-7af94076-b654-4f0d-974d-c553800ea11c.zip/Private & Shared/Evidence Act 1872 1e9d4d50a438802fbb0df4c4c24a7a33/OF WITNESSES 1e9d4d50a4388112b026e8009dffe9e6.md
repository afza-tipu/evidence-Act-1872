# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-127
Section_Number: 127
Section_Title: Section 126 to apply to interpreters, etc.
Status: Active
Tags: Witness Rule, Privilege, Legal Professional Privilege, Interpreter
Section_Text: 127. The provisions of section 126 shall apply to interpreters and the clerks or servants of ⁷⁶[Advocate].
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973
Cross_References: sec-126 (Applies provisions of S.126);; sec-165 (Privilege referred to in S.165)