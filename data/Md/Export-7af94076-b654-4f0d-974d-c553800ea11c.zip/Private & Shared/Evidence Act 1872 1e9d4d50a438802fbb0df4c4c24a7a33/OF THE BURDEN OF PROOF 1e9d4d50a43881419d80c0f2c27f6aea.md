# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-109
Section_Number: 109
Section_Title: Burden of proof as to relationship in the cases of partners, landlord and tenant, principal and agent
Status: Active
Tags: Burden of Proof, Relationship, Partnership, Landlord-Tenant, Principal-Agent
Section_Text: 109. When the question is whether persons are partners, landlord and tenant, or principal and agent, and it has been shown that they have been acting as such, the burden of proving that they do not stand, or have ceased to stand, to each other in those relationships respectively, is on the person who affirms it.