# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-45A
Section_Number: 45A
Section_Title: Opinion of experts on physical or forensic evidence
Status: Active
Tags: Procedural Rule, Expert Opinion, Physical Evidence, Forensic Evidence
Section_Text: ³⁶[45A. (1) Except by leave of the Court a witness shall not testify as an expert on physical or forensic unless a copy of his report has, pursuant to sub-section (2), been given to all the parties.\n\n(2) An expert’s report shall be addressed to the Court and not to the party on whose behalf he is examined and he shall owe a duty to help the Court.]
Amendments: Insertion by Evidence (Amendment) Act, 2022