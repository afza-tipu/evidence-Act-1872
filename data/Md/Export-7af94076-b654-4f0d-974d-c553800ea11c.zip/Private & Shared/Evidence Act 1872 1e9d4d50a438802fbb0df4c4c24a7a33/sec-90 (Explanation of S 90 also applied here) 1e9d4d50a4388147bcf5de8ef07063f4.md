# sec-90 (Explanation of S.90 also applied here)

Chapter_Number: 1973, Omission by Bangladesh Laws (Revision And Declaration) Act