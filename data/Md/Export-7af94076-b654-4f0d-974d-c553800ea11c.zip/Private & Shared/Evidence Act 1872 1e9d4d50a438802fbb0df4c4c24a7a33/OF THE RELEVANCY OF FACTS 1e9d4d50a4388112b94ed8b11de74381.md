# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-12
Section_Number: 12
Section_Title: In suits for damages, facts tending to enable Court to determine amount are relevant
Status: Active
Tags: Relevancy Rule, Damages
Section_Text: 12. In suits in which damages are claimed, any fact which will enable the Court to determine the amount of damages which ought to be awarded, is relevant.