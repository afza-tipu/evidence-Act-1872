# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-85A
Section_Number: 85A
Section_Title: Presumption as to agreements in digital forms
Status: Active
Tags: Presumption, Shall Presume, Digital Record, Agreement, Digital Signature
Section_Text: ⁵⁷[85A. The Court shall presume that every digital record purporting to be an agreement containing the digital signatures of the parties was so concluded by affixing the digital signature of the parties.]
Amendments: Insertion by Evidence (Amendment) Act, 2022