# CHARACTER WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-53
Section_Number: 53
Section_Title: In criminal cases, previous good character relevant
Status: Active
Tags: Character Evidence, Criminal Cases, Good Character
Section_Text: 53. In criminal proceedings the fact that the person accused is of a good character is relevant.
Cross_References: sec-55 (Explanation in S.55 applies)