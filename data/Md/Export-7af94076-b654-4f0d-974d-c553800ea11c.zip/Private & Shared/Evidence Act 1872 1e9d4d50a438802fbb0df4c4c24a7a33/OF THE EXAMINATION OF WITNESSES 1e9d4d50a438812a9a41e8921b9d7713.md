# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-135
Section_Number: 135
Section_Title: Order of production and examination of witnesses
Status: Active
Tags: Witness Examination, Procedure
Section_Text: 135. The order in which witnesses are produced and examined shall be regulated by the law and practice for the time being relating to civil and criminal procedure respectively, and, in the absence of any such law, by the discretion of the Court.