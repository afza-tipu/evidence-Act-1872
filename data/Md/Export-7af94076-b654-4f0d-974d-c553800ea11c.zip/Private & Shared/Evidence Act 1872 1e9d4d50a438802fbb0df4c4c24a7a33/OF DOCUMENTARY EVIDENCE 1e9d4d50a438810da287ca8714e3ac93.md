# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-72
Section_Number: 72
Section_Title: Proof of document not required by law to be attested
Status: Active
Tags: Documentary Evidence Rule, Proof, Attested Document
Section_Text: 72. An attested document not required by law to be attested may be proved as if it was unattested.