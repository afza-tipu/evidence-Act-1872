# HOW MUCH OF A STATEMENT IS TO BE PROVED

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-39
Section_Number: 39
Section_Title: What evidence to be given when statement forms part of a conversation, document, ³³[book, digital record] or series of letters or papers.
Status: Active
Tags: Rule of Evidence, Context
Section_Text: 39. When any statement of which evidence is given forms part of a longer statement, or of a conversation or part of an isolated document, or is contained in a document which ³⁴[forms part of a book, or of part of a digital record] or of a connected series of letters or papers, evidence shall be given of so much and no more of the statement, conversation, document, book of series of letters or papers as the Court considers necessary in that particular case to the full understanding of the nature and effect of the statement, and of the circumstances under which it was made.
Amendments: Substitution by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022