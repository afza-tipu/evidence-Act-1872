# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-142
Section_Number: 142
Section_Title: When they must not be asked
Status: Active
Tags: Witness Examination, Leading Question, Examination-in-chief, Re-examination
Section_Text: 142. Leading questions must not, if objected to by the adverse party be asked in an examination-in-chief, or in a re-examination, except with the permission of the Court.\n\nThe Court shall permit leading questions as to matters which are introductory or undisputed, or which have, in its opinion, been already sufficiently proved.
Cross_References: sec-141 (Refers to leading questions defined in S.141)