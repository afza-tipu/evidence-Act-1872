# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-67
Section_Number: 67
Section_Title: Proof of signature and handwriting of person alleged to have signed or written document produced
Status: Active
Tags: Documentary Evidence Rule, Proof, Signature, Handwriting
Section_Text: 67. If a document is alleged to be signed or to have been written wholly or in part by any person, the signature or the handwriting of so much of the document as is alleged to be in that person's handwriting must be proved to be in his handwriting.