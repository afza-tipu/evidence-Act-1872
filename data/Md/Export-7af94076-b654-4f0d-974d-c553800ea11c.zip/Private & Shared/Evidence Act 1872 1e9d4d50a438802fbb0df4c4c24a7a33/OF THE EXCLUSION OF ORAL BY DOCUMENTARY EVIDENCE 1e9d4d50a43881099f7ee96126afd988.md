# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-100
Section_Number: 100
Section_Title: Saving of provisions of Succession Act relating to wills
Status: Active
Tags: Saving Clause, Wills, Construction
Section_Text: 100. Nothing in this Chapter contained shall be taken to affect any of the provisions of the 69[Succession Act, 1925] as to the construction of wills.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973