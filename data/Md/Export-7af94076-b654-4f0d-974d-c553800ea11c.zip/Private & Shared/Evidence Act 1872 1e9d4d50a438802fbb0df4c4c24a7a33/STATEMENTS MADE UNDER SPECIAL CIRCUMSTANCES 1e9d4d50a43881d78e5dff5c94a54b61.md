# STATEMENTS MADE UNDER SPECIAL CIRCUMSTANCES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-35
Section_Number: 35
Section_Title: Relevancy of entry in public record ²⁴[or digital record], made in performance of duty
Status: Active
Tags: Relevancy Rule, Public Record, Digital Record, Duty
Section_Text: 35. An entry in any public or other official book, register or record ²⁵[,or digital record], stating a fact in issue or relevant fact, and made by a public servant in the discharge of his official duty, or by any other person in performance of a duty specially enjoined by the law of the country in which such book, register ²⁶[, record or digital record] is kept, is itself a relevant fact.
Amendments: Insertion by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022