# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-108
Section_Number: 108
Section_Title: Burden of proving that person is alive who has not been heard of for seven years
Status: Active
Tags: Burden of Proof, Presumption, Death
Section_Text: 108. Provided that when the question is whether a man is alive or dead, and it is proved that he has not been heard of for seven years by those who would naturally have heard of him if he had been alive, the burden of proving that he is alive is shifted to the person who affirms it.
Provisos: PROV: Provided that when the question is whether a man is alive or dead, and it is proved that he has not been heard of for seven years by those who would naturally have heard of him if he had been alive, the burden of proving that he is alive is shifted to the person who affirms it.