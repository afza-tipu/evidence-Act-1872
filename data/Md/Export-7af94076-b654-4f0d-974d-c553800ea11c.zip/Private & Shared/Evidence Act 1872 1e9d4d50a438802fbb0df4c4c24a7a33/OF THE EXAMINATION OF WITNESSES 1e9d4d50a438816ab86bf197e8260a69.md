# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-158
Section_Number: 158
Section_Title: What matters may be proved in connection with proved statement relevant under section 32 or 33
Status: Active
Tags: Witness Examination, Corroboration, Contradiction, Impeachment, Former Statement
Section_Text: 158. Whenever any statement, relevant under section 32 or 33, is proved, all matters may be proved either in order to contradict or to corroborate it, or in order to impeach or confirm the credit of the person by whom it was made, which might have been proved if that person had been called as a witness and had denied upon cross-examination the truth of the matter suggested.
Cross_References: sec-32 (Refers to statements under S.32);; sec-33 (Refers to statements under S.33);; sec-157 (Relates to corroboration under S.157)