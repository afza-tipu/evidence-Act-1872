# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-64
Section_Number: 64
Section_Title: Proof of documents by primary evidence
Status: Active
Tags: Documentary Evidence Rule, Primary Evidence
Section_Text: 64. Documents must be proved by primary evidence except in the cases hereinafter mentioned.
Cross_References: sec-65 (Exceptions mentioned in S.65)