# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-166
Section_Number: 166
Section_Title: Power of jury or assessors to put questions
Status: Active
Tags: Witness Examination, Jury, Assessors, Questioning
Section_Text: 166. In cases tried by jury or with assessors, the jury or assessors may put any questions to the witnesses, through or by leave of the Judge, which the Judge himself might put and which he considers proper.
Cross_References: sec-165 (Refers to questions Judge might put under S.165)