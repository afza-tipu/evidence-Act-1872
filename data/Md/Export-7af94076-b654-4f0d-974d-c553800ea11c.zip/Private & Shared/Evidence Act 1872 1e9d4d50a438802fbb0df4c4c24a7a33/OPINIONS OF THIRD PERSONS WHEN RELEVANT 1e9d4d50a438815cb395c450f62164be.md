# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-47A
Section_Number: 47A
Section_Title: Opinion as to digital signature where relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Digital Signature
Section_Text: ³⁷[47A.  When the Court has to form an opinion as to the digital signature of any person, the opinion of the Certifying Authority which has issued the Digital Signature Certificate is a relevant fact.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-3 (Definition of Certifying Authority)