# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-73A
Section_Number: 73A
Section_Title: Proof as to verification of digital signature
Status: Active
Tags: Documentary Evidence Rule, Proof, Digital Signature, Verification
Section_Text: ⁴⁷[73A.  In order to ascertain whether a digital signature is that of the person by whom it purports to have been affixed, the Court may direct-\n\n(a) that person or the Controller or the Certifying Authority to produce the Digital Signature Certificate;\n\n(b) any other person to apply the public key listed in the Digital Signature Certificate and verify the digital signature purported to have been affixed by that person.\n\nExplanation.- For the purpose of this section, "Controller" means the Controller appointed under sub-section (1) of section 18 of the Information and Communication Technology Act, 2006 (Act No. 39 of 2006).]