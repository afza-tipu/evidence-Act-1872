# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-80
Section_Number: 80
Section_Title: Presumption as to documents produced as record of evidence
Status: Active
Tags: Presumption, Shall Presume, Record of Evidence, Confession
Section_Text: 80. Whenever any document is produced before any Court, purporting to be a record or memorandum of the evidence, or of any part of the evidence, given by a witness in a judicial proceeding or before any officer authorized by law to take such evidence or to be a statement or confession by any prisoner or accused person, taken in accordance with law, and purporting to be signed by any Judge or Magistrate, or by any such officer as aforesaid, the Court shall presume-\n\nthat the document is genuine; that any statements as to the circumstances under which it was taken, purporting to be made by the person signing it, are true, and that such evidence, statement or confession was duly taken.