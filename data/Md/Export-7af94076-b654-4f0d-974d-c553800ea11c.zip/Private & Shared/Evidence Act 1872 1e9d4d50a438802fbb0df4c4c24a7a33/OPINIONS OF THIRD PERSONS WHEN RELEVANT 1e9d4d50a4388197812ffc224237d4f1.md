# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-46
Section_Number: 46
Section_Title: Facts bearing upon opinions of experts
Status: Active
Tags: Relevancy Rule, Expert Opinion, Corroboration, Contradiction
Section_Text: 46. Facts, not otherwise relevant, are relevant if they support or are inconsistent with the opinions of experts, when such opinions are relevant.\n\nIllustrations\n\n(a) The question is, whether A was poisoned by a certain poison.\n\nThe fact that other persons, who were poisoned by that poison, exhibited certain symptoms which experts affirm or deny to be the symptoms of that poison, is relevant.\n\n(b) The question is, whether an obstruction to a harbour is caused by a certain sea-wall.\n\nThe fact that other harbours similarly situated in other respects, but where there were no such sea-walls, began to be obstructed at about the same time, is relevant.
Illustrations: ILLUS: (a) The question is, whether A was poisoned by a certain poison.\n\nThe fact that other persons, who were poisoned by that poison, exhibited certain symptoms which experts affirm or deny to be the symptoms of that poison, is relevant.\nILLUS: (b) The question is, whether an obstruction to a harbour is caused by a certain sea-wall.\n\nThe fact that other harbours similarly situated in other respects, but where there were no such sea-walls, began to be obstructed at about the same time, is relevant.
Cross_References: sec-45 (Relates to opinions under S.45)