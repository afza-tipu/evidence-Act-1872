# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-118
Section_Number: 118
Section_Title: Who may testify
Status: Active
Tags: Witness Rule, Competency
Section_Text: 118. All persons shall be competent to testify unless the Court considers that they are prevented from understanding the questions put to them, or from giving rational answers to those questions, by tender years, extreme old age, disease, whether of body or mind, or any other cause of the same kind.\n\nExplanation.–A lunatic is not incompetent to testify, unless he is prevented by his lunacy from understanding the questions put to him and giving rational answers to them.
Explanations: EXPL: A lunatic is not incompetent to testify, unless he is prevented by his lunacy from understanding the questions put to him and giving rational answers to them.