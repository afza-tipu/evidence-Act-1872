# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-85
Section_Number: 85
Section_Title: Presumption as to powers-of-attorney
Status: Active
Tags: Presumption, Shall Presume, Power of Attorney
Section_Text: 85. The Court shall presume that every document purporting to be a power-of-attorney, and to have been executed before, and authenticated by, a notary public, or any Court, Judge, Magistrate, Bangladesh Consul or Vice-Consul, or representative of the Government, was so executed and authenticated.