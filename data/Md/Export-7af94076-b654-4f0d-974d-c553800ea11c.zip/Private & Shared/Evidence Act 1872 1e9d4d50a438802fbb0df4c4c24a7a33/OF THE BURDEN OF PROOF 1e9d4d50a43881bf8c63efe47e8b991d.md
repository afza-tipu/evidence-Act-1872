# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-107
Section_Number: 107
Section_Title: Burden of proving death of person known to have been alive within thirty years
Status: Active
Tags: Burden of Proof, Presumption, Life
Section_Text: 107. When the question is whether a man is alive or dead, and it is shown that he was alive within thirty years, the burden of proving that he is dead is on the person who affirms it.