# STATEMENTS MADE UNDER SPECIAL CIRCUMSTANCES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-37
Section_Number: 37
Section_Title: Relevancy of statement as to fact of public nature contained in certain Acts or notifications
Status: Active
Tags: Relevancy Rule, Public Fact, Legislation, Notification
Section_Text: 37. When the Court has to form an opinion as to the existence of any fact of a public nature, any statement of it, made in a recital contained in any Act of Parliament of the United Kingdom, or in any ³¹[Act of Parliament] or in a Government notification ³²[* * *] is a relevant fact.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Omission by Bangladesh Laws (Revision And Declaration) Act, 1973