# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-122
Section_Number: 122
Section_Title: Communications during marriage
Status: Active
Tags: Witness Rule, Privilege, Spousal Privilege
Section_Text: 122. No person who is or has been married shall be compelled to disclose any communication made to him during marriage by any person to whom he is or has been married: nor shall he be permitted to disclose any such communication, unless the person who made it, or his representative in interest, consents, except in suits between married persons, or proceedings in which one married person is prosecuted for any crime committed against the other.
Cross_References: sec-165 (Privilege referred to in S.165)