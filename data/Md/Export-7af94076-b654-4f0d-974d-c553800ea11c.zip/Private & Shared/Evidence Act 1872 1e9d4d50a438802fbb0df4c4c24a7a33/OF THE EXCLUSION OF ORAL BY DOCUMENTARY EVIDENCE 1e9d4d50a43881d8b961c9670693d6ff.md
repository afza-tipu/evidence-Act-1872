# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-94
Section_Number: 94
Section_Title: Exclusion of evidence against application of document of existing facts
Status: Active
Tags: Documentary Evidence Rule, Plain Meaning Rule
Section_Text: 94. When language used in a document is plain in itself, and when it applies accurately to existing facts, evidence may not be given to show that it was not meant to apply to such facts.\n\nIllustration\n\nA sells to B, by deed, "my estate at Rangpur containing 100 bighas". A has an estate at Rangpur containing 100 bighas. Evidence may not be given of the fact that the estate meant to be sold was one situated at a different place and of a different size.
Illustrations: ILLUS: A sells to B, by deed, "my estate at Rangpur containing 100 bighas". A has an estate at Rangpur containing 100 bighas. Evidence may not be given of the fact that the estate meant to be sold was one situated at a different place and of a different size.