# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-159
Section_Number: 159
Section_Title: Refreshing memory
Status: Active
Tags: Witness Examination, Refreshing Memory
Section_Text: 159. A witness may, while under examination, refresh his memory by referring to any writing made by himself at the time of the transaction concerning which he is questioned, or so soon afterwards that the Court considers it likely that the transaction was at that time fresh in his memory.\n\nThe witness may also refer to any such writing made by any other person, and read by the witness within the time aforesaid, if when he read it he knew it to be correct.\nWhen witness may use copy of document to refresh memory\nWhenever a witness may refresh his memory by reference to any document, he may, with the permission of the Court, refer to a copy of such document:\n\nProvided the Court be satisfied that there is sufficient reason for the non-production of the original.\n\nAn expert may refresh his memory by reference to professional treatises.
Provisos: PROV: Provided the Court be satisfied that there is sufficient reason for the non-production of the original.
Cross_References: sec-160 (Referenced by S.160);; sec-161 (Referenced by S.161)