# sec-3 (Certifying Authority defined in S.3)

Act_Title: "Controller" means the Controller appointed under sub-section (1) of section 18 of the Information and Communication Technology Act, 2006 (Act No. 39 of 2006)., EXPL: For the purpose of this section
Chapter_Number: 2022, Insertion by Evidence (Amendment) Act