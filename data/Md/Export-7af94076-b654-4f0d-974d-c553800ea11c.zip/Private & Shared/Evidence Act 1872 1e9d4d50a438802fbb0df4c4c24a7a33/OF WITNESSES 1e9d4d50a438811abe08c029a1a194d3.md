# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-134
Section_Number: 134
Section_Title: Number of witnesses
Status: Active
Tags: Witness Rule, Number of Witnesses
Section_Text: 134. No particular number of witnesses shall in any case be required for the proof of any fact.