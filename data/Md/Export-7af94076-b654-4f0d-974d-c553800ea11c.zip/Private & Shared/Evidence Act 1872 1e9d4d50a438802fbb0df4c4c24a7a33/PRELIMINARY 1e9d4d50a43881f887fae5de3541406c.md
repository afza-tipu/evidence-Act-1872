# PRELIMINARY

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: I
Section_ID: sec-2
Section_Number: 2
Section_Title: [Repealed]
Status: Repealed
Tags: Repealed Section, Preliminary
Section_Text: 2. [Repealed by the Repealing Act, 1938 (Act No. I of 1938), section 2 and Schedule.]
Amendments: Repeal by Repealing Act, 1938