# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-73B
Section_Number: 73B
Section_Title: Comparison of physical or forensic evidence with others, admitted or proved
Status: Active
Tags: Documentary Evidence Rule, Proof, Comparison, Physical Evidence, Forensic Evidence
Section_Text: ⁴⁸[73B. (1) In order to ascertain whether a sample of blood, semen, hair, DNA sample, any other biological substance, limbs or any part of limb, finger impression, palm impression or iris impression or foot impression belongs to or is created by that person from whom it purports to have been collected, the Court may order that it be compared with any sample which is admitted or proved to the satisfaction of the Court to have come from or been made by the person, although that sample of blood, semen, hair, DNA sample, biological substance, limbs or any part of limb, finger impression, palm impression, iris impression, foot impression or any other substance has not been produced or proved for any other purpose.\n\n(2) If there is any claim that the sample of blood, semen, hair, DNA sample, any other biological substance, limbs or any part of limb, finger impression, palm impression, iris impression, foot impression belongs to or is created by any person, the Court may direct that person to be present in Court for the purpose of enabling the Court to make that comparison.\n\n(3) In relation to proving the authenticity of physical or forensic evidence, nothing in sections 60 and 165 of this Act, should prevent the Court from seeking its production in Court as an exhibit, along with any other necessary evidence concerning its identification.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-60 (Referenced in sub-section (3));; sec-165 (Referenced in sub-section (3));; sec-89A (Related presumption in S.89A)