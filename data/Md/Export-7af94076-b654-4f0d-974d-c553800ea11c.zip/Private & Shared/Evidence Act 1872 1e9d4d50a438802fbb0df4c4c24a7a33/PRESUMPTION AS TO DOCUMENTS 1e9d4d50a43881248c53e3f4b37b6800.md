# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-85C
Section_Number: 85C
Section_Title: Presumption as to Digital Signature Certificates
Status: Active
Tags: Presumption, Shall Presume, Digital Signature Certificate
Section_Text: ⁵⁹[85C. The Court shall presume, unless contrary is proved, that the information listed in a Digital Signature Certificate is correct, except for information specified as subscriber information which has not been verified, if the certificate was accepted by the subscriber.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-3 (Relates to definition in S.3)