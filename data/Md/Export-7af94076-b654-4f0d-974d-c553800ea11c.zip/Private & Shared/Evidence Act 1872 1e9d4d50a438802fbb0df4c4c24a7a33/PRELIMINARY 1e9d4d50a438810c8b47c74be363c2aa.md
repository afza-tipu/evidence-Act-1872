# PRELIMINARY

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: I
Section_ID: sec-4
Section_Number: 4
Section_Title: "May presume""
Status: Active
Tags: Definition, Presumption, Preliminary
Section_Text: 4. Whenever it is provided by this Act that the Court may presume a fact, it may either regard such fact as proved, unless and until it is disproved, or may call for proof of it:\n“Shall presume”\nWhenever it is directed by this Act that the Court shall presume a fact, it shall regard such fact as proved, unless and until it is disproved:\n“Conclusive proof”\nWhen one fact is declared by this Act to be conclusive proof of another, the Court shall, on proof of the one fact, regard the other as proved, and shall not allow evidence to be given for the purpose of disproving it.