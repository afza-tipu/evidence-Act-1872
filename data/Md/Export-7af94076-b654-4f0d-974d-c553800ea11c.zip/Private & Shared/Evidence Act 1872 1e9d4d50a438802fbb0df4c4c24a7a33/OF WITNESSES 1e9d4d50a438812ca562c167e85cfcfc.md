# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-123
Section_Number: 123
Section_Title: Evidence as to affairs of State
Status: Active
Tags: Witness Rule, Privilege, Affairs of State
Section_Text: 123. No one shall be permitted to give any evidence derived from unpublished official records relating to any affairs of State, except with the permission of the officer at the head of the department concerned, who shall give or withhold such permission as he thinks fit.
Cross_References: sec-162 (Referenced by S.162);; sec-165 (Privilege referred to in S.165)