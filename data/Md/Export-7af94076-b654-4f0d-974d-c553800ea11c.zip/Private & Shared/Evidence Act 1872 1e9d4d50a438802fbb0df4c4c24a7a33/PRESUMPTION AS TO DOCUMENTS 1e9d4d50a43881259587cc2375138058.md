# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-88A
Section_Number: 88A
Section_Title: Presumption as to digital communication
Status: Active
Tags: Presumption, May Presume, Digital Communication
Section_Text: ⁶⁰[88A. The Court may presume that a digital communication forwarded by the originator through a digital communication or message server to the addressee to whom the message purports to be addressed corresponds with the message as fed into his computer or fed into other forms of digital device for transmission; but the Court shall not make any presumption as to the persons by whom such message was sent.\n\nExplanation.-For the purposes of this section, the expressions “addressee” and “originator” shall have the same meanings respectively assigned to them in clauses (22) and (24) of section 2 of the Information and Communication Technology Act, 2006 (Act No. 39 of 2006).]