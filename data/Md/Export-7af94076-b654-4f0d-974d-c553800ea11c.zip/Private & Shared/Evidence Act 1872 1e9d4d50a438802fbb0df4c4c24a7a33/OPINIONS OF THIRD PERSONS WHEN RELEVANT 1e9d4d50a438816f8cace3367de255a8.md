# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-51
Section_Number: 51
Section_Title: Grounds of opinion, when relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Grounds
Section_Text: 51. Whenever the opinion of any living person is relevant the grounds on which such opinion is based are also relevant.\n\nIllustration\n\nAn expert may give an account of experiments performed by him for the purpose of forming his opinion.
Illustrations: ILLUS: An expert may give an account of experiments performed by him for the purpose of forming his opinion.