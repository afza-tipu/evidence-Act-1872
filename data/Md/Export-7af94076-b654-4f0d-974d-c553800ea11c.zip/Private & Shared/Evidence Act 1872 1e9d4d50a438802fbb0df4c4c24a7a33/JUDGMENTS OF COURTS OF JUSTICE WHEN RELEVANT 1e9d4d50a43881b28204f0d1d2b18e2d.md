# JUDGMENTS OF COURTS OF JUSTICE WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-40
Section_Number: 40
Section_Title: Previous judgments relevant to bar a second suit or trial
Status: Active
Tags: Relevancy, Judgment, Res Judicata
Section_Text: 40. The existence of any judgment, order or decree which by law prevents any Court from taking cognizance of a suit or holding a trial, is a relevant fact when the question is whether such Court ought to take cognizance of such suit or to hold such trial.
Cross_References: sec-43 (Referenced by S.43);; sec-44 (Referenced by S.44)