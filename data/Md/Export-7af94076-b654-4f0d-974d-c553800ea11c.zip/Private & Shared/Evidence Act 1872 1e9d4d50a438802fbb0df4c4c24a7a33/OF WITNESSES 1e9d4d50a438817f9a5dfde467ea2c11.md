# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-124
Section_Number: 124
Section_Title: Official communications
Status: Active
Tags: Witness Rule, Privilege, Official Communication
Section_Text: 124. No public officer shall be compelled to disclose communications made to him in official confidence, when he considers that the public interests would suffer by the disclosure.
Cross_References: sec-165 (Privilege referred to in S.165)