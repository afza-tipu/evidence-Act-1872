# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-62
Section_Number: 62
Section_Title: Primary evidence
Status: Active
Tags: Definition, Primary Evidence
Section_Text: 62. Primary evidence means the document itself produced for the inspection of the Court.\n\nExplanation 1.-Where a document is executed in several parts, each part is primary evidence of the document.\n\nWhere a document is executed in counterpart, each counterpart being executed by one or some of the parties only, each counterpart is primary evidence as against the parties executing it.\n\nExplanation 2.-Where a number of documents are all made by one uniform process, as in the case of printing, lithography or photography, each is primary evidence of the contents of the rest; but, where they are all copies of a common original, they are not primary evidence of the contents of the original.\n\nIllustration\n\nA person is shown to have been in possession of a number of placards, all printed at one time prove one original. Any one of the placards is primary evidence of the contents of any other, but no one of them is primary evidence of the contents of the original.
Explanations: EXPL: Where a document is executed in several parts, each part is primary evidence of the document.\n\nWhere a document is executed in counterpart, each counterpart being executed by one or some of the parties only, each counterpart is primary evidence as against the parties executing it.\nEXPL: Where a number of documents are all made by one uniform process, as in the case of printing, lithography or photography, each is primary evidence of the contents of the rest; but, where they are all copies of a common original, they are not primary evidence of the contents of the original.
Illustrations: ILLUS: A person is shown to have been in possession of a number of placards, all printed at one time prove one original. Any one of the placards is primary evidence of the contents of any other, but no one of them is primary evidence of the contents of the original.