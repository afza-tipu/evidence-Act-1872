# STATEMENTS MADE UNDER SPECIAL CIRCUMSTANCES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-36
Section_Number: 36
Section_Title: Relevancy of statements in maps, charts ²⁷[, plans and digital record]
Status: Active
Tags: Relevancy Rule, Maps, Charts, Plans, Digital Record
Section_Text: 36. Statements of facts in issue or relevant facts, made in published ²⁸[maps, charts or digital record] generally offered for public sale, or in ²⁹[maps, plans or digital record] made under the authority of the Government, as to matters usually represented or stated in such ³⁰[maps, charts, plans or digital record], are themselves relevant facts.
Amendments: Substitution by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022;; Substitution by Evidence (Amendment) Act, 2022
Cross_References: sec-87 (Referenced by S.87)