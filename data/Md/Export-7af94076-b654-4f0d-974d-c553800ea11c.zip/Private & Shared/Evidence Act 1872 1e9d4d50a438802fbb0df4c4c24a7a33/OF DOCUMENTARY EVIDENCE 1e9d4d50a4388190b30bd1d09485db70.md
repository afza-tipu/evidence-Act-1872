# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-69
Section_Number: 69
Section_Title: Proof where no attesting witness found
Status: Active
Tags: Documentary Evidence Rule, Proof, Attested Document
Section_Text: 69. If no such attesting witness can be found, or if the document purports to have been executed in the United Kingdom, it must be proved that the attestation of one attesting witness at least is in his handwriting, and that the signature of the person executing the document is in the handwriting of that person.