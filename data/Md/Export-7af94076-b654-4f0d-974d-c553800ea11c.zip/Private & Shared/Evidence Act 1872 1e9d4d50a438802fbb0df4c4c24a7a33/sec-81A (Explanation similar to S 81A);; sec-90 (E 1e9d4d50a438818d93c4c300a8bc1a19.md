# sec-81A (Explanation similar to S.81A);; sec-90 (Explanation similar to S.90)

Act_Title: EXPL: Digital records are said to be in proper custody if they are in the place in which, and under the care of the person with whom, or the circumstances of the particular case are such as to render such an origin probable., they naturally be; but no custody is improper if it is proved to have had a legitimate origin
Chapter_Number: 2022, Insertion by Evidence (Amendment) Act