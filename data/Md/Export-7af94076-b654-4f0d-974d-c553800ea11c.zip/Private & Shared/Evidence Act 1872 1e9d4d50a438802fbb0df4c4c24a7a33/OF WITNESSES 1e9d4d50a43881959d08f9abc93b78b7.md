# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-133
Section_Number: 133
Section_Title: Accomplice
Status: Active
Tags: Witness Rule, Accomplice, Corroboration
Section_Text: 133. An accomplice shall be a competent witness against an accused person; and a conviction is not illegal merely because it proceeds upon the uncorroborated testimony of an accomplice.