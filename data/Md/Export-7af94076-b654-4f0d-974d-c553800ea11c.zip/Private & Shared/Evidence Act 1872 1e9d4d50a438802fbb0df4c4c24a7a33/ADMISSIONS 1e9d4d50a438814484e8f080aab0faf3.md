# ADMISSIONS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-19
Section_Number: 19
Section_Title: Admissions by persons whose position must be proved as against party to suit
Status: Active
Tags: Admission Rule, Third Party Statement
Section_Text: 19. Statements made by persons whose position or liability it is necessary to prove as against any party to the suit, are admissions, if such statements would be relevant as against such persons in relation to such position or liability in a suit brought by or against them, and if they are made whilst the person making them occupies such position or is subject to such liability.\n\nIllustrations\n\nA undertakes to collect rents for B.\n\nB sues A for not collecting rent due from C to B.\n\nA denies that rent was due from C to B.\n\nA statement by C that he owed B rent is an admission, and is a relevant fact as against A, if A denies that C did owe rent to B.
Illustrations: ILLUS: A undertakes to collect rents for B.\n\nB sues A for not collecting rent due from C to B.\n\nA denies that rent was due from C to B.\n\nA statement by C that he owed B rent is an admission, and is a relevant fact as against A, if A denies that C did owe rent to B.