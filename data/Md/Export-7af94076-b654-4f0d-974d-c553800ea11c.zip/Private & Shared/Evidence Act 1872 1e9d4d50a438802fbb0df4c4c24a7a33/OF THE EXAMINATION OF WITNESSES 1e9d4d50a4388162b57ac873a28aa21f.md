# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-163
Section_Number: 163
Section_Title: Giving, as evidence, of document called for and produced on notice
Status: Active
Tags: Witness Examination, Production of Document, Notice to Produce
Section_Text: 163. When a party calls for a document which he has given the other party notice to produce, and such document is produced and inspected by the party calling for its production, he is bound to give it as evidence if the party producing it requires him to do so.