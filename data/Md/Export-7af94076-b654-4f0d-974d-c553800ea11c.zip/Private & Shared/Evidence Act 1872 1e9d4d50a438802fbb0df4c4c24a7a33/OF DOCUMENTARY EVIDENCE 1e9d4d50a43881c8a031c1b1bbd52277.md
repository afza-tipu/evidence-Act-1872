# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-71
Section_Number: 71
Section_Title: Proof when attesting witness denies the execution
Status: Active
Tags: Documentary Evidence Rule, Proof, Attested Document
Section_Text: 71. If the attesting witness denies or does not recollect the execution of the document, its execution may be proved by other evidence.