# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-90A
Section_Number: 90A
Section_Title: Presumption as to digital records five years old
Status: Active
Tags: Presumption, May Presume, Ancient Document, Digital Record, Proper Custody
Section_Text: ⁶²[90A. Where any digital record, purporting or proved to be five years old, is produced from any custody which the Court in the particular case considers proper, the Court may presume that the digital signature which purports to be the digital signature of any particular person was so affixed by him or any person authorized by him in this behalf.\n\nExplanation.- Digital records are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they naturally be; but no custody is improper if it is proved to have had a legitimate origin, or the circumstances of the particular case are such as to render such an origin probable.]
Explanations: EXPL: Digital records are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they naturally be; but no custody is improper if it is proved to have had a legitimate origin, or the circumstances of the particular case are such as to render such an origin probable.
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-81A (Explanation similar to S.81A);; sec-90 (Explanation similar to S.90)