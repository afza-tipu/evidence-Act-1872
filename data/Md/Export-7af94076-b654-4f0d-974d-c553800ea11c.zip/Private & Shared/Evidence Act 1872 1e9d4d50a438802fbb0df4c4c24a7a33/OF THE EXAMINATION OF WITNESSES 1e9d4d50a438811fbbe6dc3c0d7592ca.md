# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-147
Section_Number: 147
Section_Title: When witness to be compelled to answer
Status: Active
Tags: Witness Examination, Cross-examination, Compelled Answer, Self-incrimination
Section_Text: 147. If any such question relates to a matter relevant to the suit or proceeding, the provisions of section 132 shall apply thereto.
Cross_References: sec-132 (Applies provisions of S.132);; sec-146 (Refers to questions under S.146)