# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-82
Section_Number: 82
Section_Title: Presumption as to document admissible in England without proof of seal or signature
Status: Active
Tags: Presumption, Shall Presume, Foreign Document
Section_Text: 82. When any document is produced before any Court, purporting to be a document which, by the law in force for the time being in England and Ireland, would be admissible in proof of any particular in any Court of Justice in England or Ireland, without proof of the seal or stamp or signature authenticating it, or of the judicial or official character claimed by the person by whom it purports to be signed, the Court shall presume that such seal, stamp or signature is genuine, and that the person signing it held, at the time when he signed it, the judicial or official character which he claims,\n\nand the document shall be admissible for the same purpose for which it would be admissible in England or Ireland.