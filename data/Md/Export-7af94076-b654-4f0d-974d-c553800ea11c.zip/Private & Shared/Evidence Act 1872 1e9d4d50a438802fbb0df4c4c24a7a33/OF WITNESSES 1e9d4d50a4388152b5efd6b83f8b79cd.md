# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-131
Section_Number: 131
Section_Title: Production of documents which another person, having possession, could refuse to produce
Status: Active
Tags: Witness Rule, Privilege, Production of Document
Section_Text: 131. No one shall be compelled to produce documents in his possession, which any other person would be entitled to refuse to produce if they were in his possession, unless such last-mentioned person consents to their production.
Cross_References: sec-165 (Privilege referred to in S.165)