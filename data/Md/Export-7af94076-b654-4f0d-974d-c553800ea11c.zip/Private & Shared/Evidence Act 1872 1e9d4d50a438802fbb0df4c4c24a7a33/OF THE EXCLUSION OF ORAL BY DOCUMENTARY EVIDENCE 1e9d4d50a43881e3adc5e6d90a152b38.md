# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-93
Section_Number: 93
Section_Title: Exclusion of evidence to explain or amend ambiguous document
Status: Active
Tags: Documentary Evidence Rule, Ambiguity, Patent Ambiguity
Section_Text: 93. When the language used in a document is, on its face, ambiguous or defective, evidence may not be given of facts which would show its meaning or supply its defects.\n\nIllustrations\n\n(a) A agrees, in writing, to sell a horse to B for Taka 1,000 or Taka 1,500. Evidence cannot be given to show which price was to be given.\n\n(b) A deed contains blanks. Evidence cannot be given of facts which would show how they were meant to be filled.
Illustrations: ILLUS: (a) A agrees, in writing, to sell a horse to B for Taka 1,000 or Taka 1,500. Evidence cannot be given to show which price was to be given.\nILLUS: (b) A deed contains blanks. Evidence cannot be given of facts which would show how they were meant to be filled.