# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-11
Section_Number: 11
Section_Title: When facts not otherwise relevant become relevant
Status: Active
Tags: Relevancy Rule, Alibi, Highly Probable/Improbable
Section_Text: 11. Facts not otherwise relevant are relevant–\n\n(1) If they are inconsistent with any fact in issue or relevant fact;\n\n(2) If by themselves or in connection with other facts they make the existence or non-existence of any fact in issue or relevant fact highly probable or improbable.\n\nIllustrations\n\n(a) The question is whether A committed a crime at Chittagong on a certain day.\n\nThe fact that, on that day, A was at 12[Dhaka] is relevant.\n\nThe fact that, near the time when the crime was committed, A was at a distance from the place where it was committed, which would render it highly improbable, though not impossible, that he committed it, is relevant.\n\n(b) The question is, whether A committed a crime.\n\nThe circumstances are such that the crime must have been committed either by A, B, C or D. Every fact which shows that the crime could have been committed by no one else and that it was not committed by either B, C or D, is relevant.
Illustrations: ILLUS: (a) The question is whether A committed a crime at Chittagong on a certain day.\n\nThe fact that, on that day, A was at 12[Dhaka] is relevant.\n\nThe fact that, near the time when the crime was committed, A was at a distance from the place where it was committed, which would render it highly improbable, though not impossible, that he committed it, is relevant.\nILLUS: (b) The question is, whether A committed a crime.\n\nThe circumstances are such that the crime must have been committed either by A, B, C or D. Every fact which shows that the crime could have been committed by no one else and that it was not committed by either B, C or D, is relevant.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973