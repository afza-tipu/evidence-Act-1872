# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-85B
Section_Number: 85B
Section_Title: Presumption as to digital record and digital signatures
Status: Active
Tags: Presumption, Shall Presume, Digital Record, Digital Signature, Secure Record
Section_Text: ⁵⁸[85B. (1) In any proceedings involving a secure digital record, the Court shall presume unless contrary is proved, that the secure digital record has not been altered since the point of time to which the secure status relates.\n\n(2) In any proceedings, involving secure digital signature, the Court shall presume unless the contrary is proved that-\n\n(a) the secure digital signature is affixed by subscriber with the intention of signing or approving the digital record;\n\n(b) except in the case of a secure digital record or a secure digital signature, nothing in this section shall create any presumption relating to authenticity and integrity of the digital record or any digital signature.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-67A (Exception for secure digital signature)