# CHARACTER WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-54
Section_Number: 54
Section_Title: Previous bad character not relevant, except in reply
Status: Active
Tags: Character Evidence, Criminal Cases, Bad Character, Previous Conviction
Section_Text: 54. In criminal proceedings the fact that the accused person has a bad character is irrelevant, unless evidence has been given that he has a good character, in which case it becomes relevant.\n\nExplanation 1.–This section does not apply to cases in which the bad character of any person is itself a fact in issue.\n\nExplanation 2.–A previous conviction is relevant as evidence of bad character.
Explanations: EXPL: This section does not apply to cases in which the bad character of any person is itself a fact in issue.\nEXPL: A previous conviction is relevant as evidence of bad character.
Cross_References: sec-55 (Explanation in S.55 applies)