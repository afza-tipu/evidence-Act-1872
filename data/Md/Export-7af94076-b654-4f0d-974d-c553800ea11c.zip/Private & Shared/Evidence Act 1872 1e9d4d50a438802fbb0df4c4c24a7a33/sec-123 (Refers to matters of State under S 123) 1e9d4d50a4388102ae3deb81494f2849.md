# sec-123 (Refers to matters of State under S.123)

Chapter_Number: 1973, Omission by Bangladesh Laws (Revision And Declaration) Act