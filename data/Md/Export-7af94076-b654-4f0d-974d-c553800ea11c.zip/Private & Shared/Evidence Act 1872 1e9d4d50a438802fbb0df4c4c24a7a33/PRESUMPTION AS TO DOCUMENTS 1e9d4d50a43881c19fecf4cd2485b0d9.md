# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-84
Section_Number: 84
Section_Title: Presumption as to collections of laws and reports of decisions
Status: Active
Tags: Presumption, Shall Presume, Law Books, Gazette, Reports of Decisions
Section_Text: 84. The Court shall presume the genuineness of ⁵⁵[every book or Gazette] purporting to be printed or published under the authority of the Government of any country, and to contain any of the laws of that country,\n\nand of ⁵⁶[every book or Gazette] purporting to contain reports of decisions of the Courts of such country.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973