# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-48
Section_Number: 48
Section_Title: Opinion as to existence of right or custom, when relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Right, Custom
Section_Text: 48. When the Court has to form an opinion as to the existence of any general custom or right, the opinions, as to the existence of such custom or right, of persons who would be likely to know of its existence if it existed, are relevant.\n\nExplanation.–The expression "general custom or right" includes customs or rights common to any considerable class of persons.\n\nIllustration\n\nThe right of the villagers of a particular village to use the water of a particular well is a general right within the meaning of this section.
Explanations: EXPL: The expression "general custom or right" includes customs or rights common to any considerable class of persons.
Illustrations: ILLUS: The right of the villagers of a particular village to use the water of a particular well is a general right within the meaning of this section.