# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-141
Section_Number: 141
Section_Title: Leading questions
Status: Active
Tags: Definition, Witness Examination, Leading Question
Section_Text: 141. Any question suggesting the answer which the person putting it wishes or expects to receive is called a leading question.
Cross_References: sec-142 (When not to be asked under S.142);; sec-143 (When may be asked under S.143)