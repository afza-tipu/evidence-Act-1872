# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-165
Section_Number: 165
Section_Title: Judge’s power to put questions or order production
Status: Active
Tags: Witness Examination, Judge's Power, Questioning, Production of Document
Section_Text: 165. The Judge may, in order to discover or to obtain proper proof of relevant facts, ask any question he pleases, in any form, at any time, of any witness, or of the parties about any fact relevant or irrelevant; and may order the production of any document or thing: and neither the parties nor their agents shall be entitled to make any objection to any such question or order, nor, without the leave of the Court, to cross-examine any witness upon any answer given in reply to any such question:\n\nProvided that the judgment must be based upon facts declared by this Act to be relevant, and duly proved:\n\nProvided also that this section shall not authorize any Judge to compel any witness to answer any question or to produce any document which such witness would be entitled to refuse to\n\nanswer or produce under sections 121 to 131, both inclusive, if the question were asked or the document were called for by the adverse party; nor shall the Judge ask any question which it would be improper for any other person to ask under section 148 or 149; nor shall he dispense with primary evidence of any document, except in the cases herein- before excepted.