# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-70
Section_Number: 70
Section_Title: Admission of execution by party to attested document
Status: Active
Tags: Documentary Evidence Rule, Proof, Attested Document, Admission
Section_Text: 70. The admission of a party to an attested document of its execution by himself shall be sufficient proof of its execution as against him, though it be a document required by law to be attested.