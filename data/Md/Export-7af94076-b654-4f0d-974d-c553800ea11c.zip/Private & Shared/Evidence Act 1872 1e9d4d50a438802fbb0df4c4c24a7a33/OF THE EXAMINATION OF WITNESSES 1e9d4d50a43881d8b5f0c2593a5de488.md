# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-143
Section_Number: 143
Section_Title: When they may be asked
Status: Active
Tags: Witness Examination, Leading Question, Cross-examination
Section_Text: 143. Leading questions may be asked in cross-examination.
Cross_References: sec-141 (Refers to leading questions defined in S.141)