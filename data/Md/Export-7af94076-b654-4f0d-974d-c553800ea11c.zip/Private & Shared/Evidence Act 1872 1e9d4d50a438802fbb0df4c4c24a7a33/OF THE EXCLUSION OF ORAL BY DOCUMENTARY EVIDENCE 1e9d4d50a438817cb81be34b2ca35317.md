# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-95
Section_Number: 95
Section_Title: Evidence as to document unmeaning in reference to existing facts
Status: Active
Tags: Documentary Evidence Rule, Ambiguity, Latent Ambiguity
Section_Text: 95. When language used in a document is plain in itself, but is unmeaning in reference to existing facts, evidence may be given to show that it was used in a peculiar sense.\n\nIllustrations\n\nA sells to B, by deed "my house in 63[Dhaka]".\n\nA had no house in 64[Dhaka], but it appears that he had a house at 65[Narayanganj], of which B had been in possession since the execution of the deed.\n\nThese facts may be proved to show that the deed related to the house at 66[Narayanganj].
Illustrations: ILLUS: A sells to B, by deed "my house in 63[Dhaka]".\n\nA had no house in 64[Dhaka], but it appears that he had a house at 65[Narayanganj], of which B had been in possession since the execution of the deed.\n\nThese facts may be proved to show that the deed related to the house at 66[Narayanganj].
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973