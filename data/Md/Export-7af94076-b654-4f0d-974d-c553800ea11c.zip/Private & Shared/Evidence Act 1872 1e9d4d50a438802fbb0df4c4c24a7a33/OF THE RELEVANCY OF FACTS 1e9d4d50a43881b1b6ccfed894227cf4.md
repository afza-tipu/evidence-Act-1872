# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-5
Section_Number: 5
Section_Title: Evidence may be given of facts in issue and relevant facts
Status: Active
Tags: Relevancy Rule, Scope of Evidence
Section_Text: 5. Evidence may be given in any suit or proceeding of the existence or non-existence of every fact in issue and of such other fact as are hereinafter declared to be relevant, and of no others.\n\nExplanation.-This section shall not enable any person to give evidence of a fact which he is disentitled to prove by any provision of the law for the time being in force relating to Civil Procedure.\n\nIllustrations\n\n(a) A is tried for the murder of B by beating him with a club with the intention of causing his death.\n\nAt A's trial the following facts are in issue:–\n\nA's beating B with the club;\n\nA's causing B's death by such beating;\n\nA's intention to cause B's death.\n\n(b) A suitor does not bring with him, and have in readiness for production at the first hearing of the case, a bond on which he relies. This section does not enable him to produce the bond or prove its contents at a subsequent stage of the proceedings, otherwise than in accordance with the conditions prescribed by the Code of Civil Procedure.
Explanations: EXPL: This section shall not enable any person to give evidence of a fact which he is disentitled to prove by any provision of the law for the time being in force relating to Civil Procedure.
Illustrations: ILLUS: (a) A is tried for the murder of B by beating him with a club with the intention of causing his death.\n\nAt A's trial the following facts are in issue:–\n\nA's beating B with the club;\n\nA's causing B's death by such beating;\n\nA's intention to cause B's death.\nILLUS: (b) A suitor does not bring with him, and have in readiness for production at the first hearing of the case, a bond on which he relies. This section does not enable him to produce the bond or prove its contents at a subsequent stage of the proceedings, otherwise than in accordance with the conditions prescribed by the Code of Civil Procedure.