# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-157
Section_Number: 157
Section_Title: Former statements of witness may be proved to corroborate later testimony as to same fact
Status: Active
Tags: Witness Examination, Corroboration, Former Statement
Section_Text: 157. In order to corroborate the testimony of a witness, any former statement made by such witness relating to the same fact at or about the time when the fact took place, or before any authority legally competent to investigate the fact, may be proved.
Cross_References: sec-8 (Referenced by S.8 Illustrations (j), (k));; sec-158 (Referenced by S.158)