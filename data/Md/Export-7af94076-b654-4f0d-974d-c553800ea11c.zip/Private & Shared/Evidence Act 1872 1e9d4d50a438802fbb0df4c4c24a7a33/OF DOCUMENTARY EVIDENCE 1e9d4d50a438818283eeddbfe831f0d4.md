# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-67A
Section_Number: 67A
Section_Title: Proof as to digital signature
Status: Active
Tags: Documentary Evidence Rule, Proof, Digital Signature
Section_Text: ⁴⁶[67A.  Except in the case of a secure digital signature, if the digital signature of any subscriber is alleged to have been affixed to a digital record the fact that such digital signature is the digital signature of the subscriber must be proved.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-85B (Exception for secure digital signature)