# OF THE EXCLUSION OF ORAL BY DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: VI
Section_ID: sec-98
Section_Number: 98
Section_Title: Evidence as to meaning of illegible characters, etc.
Status: Active
Tags: Documentary Evidence Rule, Interpretation, Illegible, Technical Terms
Section_Text: 98. Evidence may be given to show the meaning of illegible or not commonly intelligible characters, of foreign, obsolete, technical, local and provincial expressions, of abbreviations and of words used in a peculiar sense.\n\nIllustration\n\nA, a sculptor, agrees to sell to B, "all my mods". A has both models and modeling tools. Evidence may be given to show which he meant to sell.
Illustrations: ILLUS: A, a sculptor, agrees to sell to B, "all my mods". A has both models and modeling tools. Evidence may be given to show which he meant to sell.