# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-138
Section_Number: 138
Section_Title: Order of examinations
Status: Active
Tags: Witness Examination, Order of Examination, Scope of Examination
Section_Text: 138. Witnesses shall be first examined-in-chief, then (if the adverse party so desires) cross-examined, then (if the party calling him so desires) re-examined.\n\nThe examination and cross-examination must relate to relevant facts but the cross-examination need not be confined to the facts to which the witness testified on his examination-in-chief.\nDirection of re-examination\nThe re-examination shall be directed to the explanation of matters referred to in cross-examination; and, if new matter is, by permission of the Court, introduced in re-examination, the adverse party may further cross-examine upon that matter.
Cross_References: sec-137 (Refers to terms defined in S.137)