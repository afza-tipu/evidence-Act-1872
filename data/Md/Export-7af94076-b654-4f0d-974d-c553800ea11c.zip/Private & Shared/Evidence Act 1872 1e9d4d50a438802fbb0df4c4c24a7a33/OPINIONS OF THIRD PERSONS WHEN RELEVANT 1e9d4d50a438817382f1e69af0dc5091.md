# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-50
Section_Number: 50
Section_Title: Opinion on relationship, when relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Relationship, Conduct
Section_Text: 50. When the Court has to form an opinion as to the relationship of one person to another the opinion, expressed by conduct, as to the existence of such relationship, of any person who, as a member of the family or otherwise, has special means of knowledge on the subject, is a relevant fact:\n\nProvided that such opinion shall not be sufficient to prove a marriage in proceedings under the Divorce Act, or in prosecutions under section 494, 495, 497 or 498 of the ³⁸[* * *] Penal Code.\n\nIllustrations\n\n(a) The question is, whether A and B were married.\n\nThe fact that they were usually received and treated by their friends as husband and wife, is relevant.\n\n(b) The question is, whether A was the legitimate son of B. The fact that A was always treated as such by members of the family, is relevant.
Illustrations: ILLUS: (a) The question is, whether A and B were married.\n\nThe fact that they were usually received and treated by their friends as husband and wife, is relevant.\nILLUS: (b) The question is, whether A was the legitimate son of B. The fact that A was always treated as such by members of the family, is relevant.
Provisos: PROV: Provided that such opinion shall not be sufficient to prove a marriage in proceedings under the Divorce Act, or in prosecutions under section 494, 495, 497 or 498 of the ³⁸[* * *] Penal Code.
Amendments: Omission by Bangladesh Laws (Revision And Declaration) Act, 1973