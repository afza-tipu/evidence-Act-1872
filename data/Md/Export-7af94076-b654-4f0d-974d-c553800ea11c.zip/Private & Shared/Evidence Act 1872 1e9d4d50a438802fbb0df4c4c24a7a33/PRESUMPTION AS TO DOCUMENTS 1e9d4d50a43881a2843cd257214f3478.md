# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-81
Section_Number: 81
Section_Title: [Omitted]
Status: Omitted
Tags: Omitted Section
Section_Text: 81. [Omitted by section 3 and 2nd Schedule of the Bangladesh Laws (Revision And Declaration) Act, 1973 (Act No. VIII of 1973).]