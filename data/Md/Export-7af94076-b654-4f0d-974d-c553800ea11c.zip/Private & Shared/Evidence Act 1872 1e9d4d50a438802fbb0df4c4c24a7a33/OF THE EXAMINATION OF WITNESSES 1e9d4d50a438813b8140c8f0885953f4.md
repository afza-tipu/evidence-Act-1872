# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-151
Section_Number: 151
Section_Title: Indecent and scandalous questions
Status: Active
Tags: Witness Examination, Improper Question, Indecent, Scandalous
Section_Text: 151. The Court may forbid any questions or inquiries which it regards as indecent or scandalous, although such questions or inquiries may have some bearing on the questions before the Court, unless they relate to facts in issue, or to matters necessary to be known in order to determine whether or not the facts in issue existed.
Cross_References: sec-165 (Judge's power limited by this section)