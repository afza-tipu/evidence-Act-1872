# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-65A
Section_Number: 65A
Section_Title: Special provisions as to evidence relating to digital record
Status: Active
Tags: Documentary Evidence Rule, Digital Record
Section_Text: ⁴⁴[65A.  The contents of digital records may be proved in accordance with the provisions of section 65B.]
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-65B (Refers to S.65B for proof)