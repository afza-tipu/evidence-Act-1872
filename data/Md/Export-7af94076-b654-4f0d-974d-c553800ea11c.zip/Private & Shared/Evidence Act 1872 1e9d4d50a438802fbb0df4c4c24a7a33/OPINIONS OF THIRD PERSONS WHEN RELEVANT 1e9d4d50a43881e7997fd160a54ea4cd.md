# OPINIONS OF THIRD PERSONS WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-49
Section_Number: 49
Section_Title: Opinion as to usages, tenets, etc., when relevant
Status: Active
Tags: Relevancy, Opinion Evidence, Usages, Tenets, Meaning of Words
Section_Text: 49. When the Court has to form an opinion as to–\n\nthe usages and tenets of any body of men or family,\n\nthe constitution and government of any religious or charitable foundation or,\n\nthe meaning of words or terms used in particular districts or by particular classes of people,\n\nthe opinions of persons having special means of knowledge thereon, are relevant facts.