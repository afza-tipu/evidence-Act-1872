# CHARACTER WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-52
Section_Number: 52
Section_Title: In civil cases, character to prove conduct imputed, irrelevant
Status: Active
Tags: Character Evidence, Civil Cases
Section_Text: 52. In civil cases the fact that the character of any person concerned is such as to render probable or improbable any conduct imputed to him is irrelevant, except in so far as such character appears from facts otherwise relevant
Cross_References: sec-55 (Explanation in S.55 applies)