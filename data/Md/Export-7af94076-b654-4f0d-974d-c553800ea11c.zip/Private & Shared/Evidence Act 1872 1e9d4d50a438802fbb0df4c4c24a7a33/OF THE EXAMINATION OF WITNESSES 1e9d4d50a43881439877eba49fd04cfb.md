# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-146
Section_Number: 146
Section_Title: Questions lawful in cross-examination
Status: Active
Tags: Witness Examination, Cross-examination, Veracity, Credit
Section_Text: 146. When a witness is cross-examined, he may, in addition to the questions hereinbefore referred to, be asked any questions which tend –\n\n(1) to test his veracity,\n\n(2) to discover who he is and what is his position in life, or\n\n(3) to shake his credit, by injuring his character, although the answer to such questions might tend directly or indirectly to criminate him or might expose or tend directly or indirectly to expose him to a penalty or forfeiture⁷⁷[:\n\nProvided that in a prosecution for an offence of rape or attempt to rape, no question under clause (3) can be asked in the cross-examination as to general immoral character or previous sexual behaviour of the victim:\n\nProvided further that such question can only be asked with the permission of the Court, if it appears to the Court necessary for the ends of justice.]