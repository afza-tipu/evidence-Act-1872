# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-125
Section_Number: 125
Section_Title: Information as to commission of offences
Status: Active
Tags: Witness Rule, Privilege, Police, Magistrate, Revenue Officer
Section_Text: 125. No Magistrate or Police-officer shall be compelled to say whence he got any information as to the commission of any offence, and no Revenue-officer shall be compelled to say whence he got any information as to the commission of any offence against the public revenue.\n\nExplanation.–"Revenue-officer" in this section means any officer employed in or about the business of any branch of the public revenue.
Explanations: EXPL: "Revenue-officer" in this section means any officer employed in or about the business of any branch of the public revenue.
Cross_References: sec-165 (Privilege referred to in S.165)