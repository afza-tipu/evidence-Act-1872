# STATEMENTS MADE UNDER SPECIAL CIRCUMSTANCES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-34
Section_Number: 34
Section_Title: Entries in books of account ²²[or digital record] when relevant
Status: Active
Tags: Relevancy Rule, Books of Account, Digital Record
Section_Text: 34. Entries in books of account ²³[ or digital record], regularly kept in the course of business, are relevant whenever they refer to a matter into which the Court has to inquire, but such statements shall not alone be sufficient evidence to charge any person with liability.\n\nIllustration\n\nA sues B for Taka 1,000, and shows entries in his account books showing B to be indebted to him to this amount. The entries are relevant, but are not sufficient, without other evidence, to prove the debt.
Illustrations: ILLUS: A sues B for Taka 1,000, and shows entries in his account books showing B to be indebted to him to this amount. The entries are relevant, but are not sufficient, without other evidence, to prove the debt.
Amendments: Insertion by Evidence (Amendment) Act, 2022;; Insertion by Evidence (Amendment) Act, 2022