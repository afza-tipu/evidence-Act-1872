# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-132
Section_Number: 132
Section_Title: Witness not excused from answering on ground that answer will criminate
Status: Active
Tags: Witness Rule, Self-incrimination, Privilege
Section_Text: 132. A witness shall not be excused from answering any question as to any matter relevant to the matter in issue in any suit or in any civil or criminal proceeding, upon the ground that the answer to such question will criminate, or may tend directly or indirectly to criminate, such witness, or that it will expose, or tend directly or indirectly to expose, such witness to a penalty or forfeiture of any kind:\n\nProvided that no such answer, which a witness shall be compelled to give, shall subject him to any arrest or prosecution, or be proved against him in any criminal proceeding, except a prosecution for giving false evidence by such answer.
Provisos: PROV: Provided that no such answer, which a witness shall be compelled to give, shall subject him to any arrest or prosecution, or be proved against him in any criminal proceeding, except a prosecution for giving false evidence by such answer.
Cross_References: sec-146 (Referenced by S.146);; sec-147 (Applied by S.147)