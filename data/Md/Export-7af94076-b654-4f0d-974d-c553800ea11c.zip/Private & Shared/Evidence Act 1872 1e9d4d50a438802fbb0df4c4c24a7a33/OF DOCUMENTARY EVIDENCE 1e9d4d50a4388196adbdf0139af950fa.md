# OF DOCUMENTARY EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-63
Section_Number: 63
Section_Title: Secondary evidence
Status: Active
Tags: Definition, Secondary Evidence
Section_Text: 63. Secondary evidence means and includes-\n\n(1) certified copies given under the provisions hereinafter contained;\n\n(2) copies made from the original by mechanical processes which in themselves insure the accuracy of the copy, and copies compared with such copies;\n\n(3) copies made from or compared with the original;\n\n(4) counterparts of documents as against the parties who did not execute them;\n\n(5) oral accounts of the contents of a document given by some person who has himself seen it.\n\nIllustrations\n\n(a) A photograph of an original is secondary evidence of its contents, though the two have not been compared, if it is proved that the thing photographed was the original.\n\n(b) A copy, compared with a copy of a letter made by a copying machine is secondary evidence of the contents of the letter, if it is shown that the copy made by the copying machine was made from the original.\n\n(c) A copy transcribed from a copy, but afterwards compared with the original is secondary evidence; but the copy not so compared is not secondary evidence of the original, although the copy from which it was transcribed was compared with the original.\n\n(d) Neither an oral account of a copy compared with the original, nor an oral account of a photograph or machine-copy of the original, is secondary evidence of the original.
Illustrations: ILLUS: (a) A photograph of an original is secondary evidence of its contents, though the two have not been compared, if it is proved that the thing photographed was the original.\nILLUS: (b) A copy, compared with a copy of a letter made by a copying machine is secondary evidence of the contents of the letter, if it is shown that the copy made by the copying machine was made from the original.\nILLUS: (c) A copy transcribed from a copy, but afterwards compared with the original is secondary evidence; but the copy not so compared is not secondary evidence of the original, although the copy from which it was transcribed was compared with the original.\nILLUS: (d) Neither an oral account of a copy compared with the original, nor an oral account of a photograph or machine-copy of the original, is secondary evidence of the original.