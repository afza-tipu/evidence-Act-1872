# JUDGMENTS OF COURTS OF JUSTICE WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-44
Section_Number: 44
Section_Title: Fraud or collusion in obtaining judgment, or in-competency of Court, may be proved
Status: Active
Tags: Rule of Evidence, Judgment, Fraud, Collusion, Competency
Section_Text: 44. Any party to a suit or other proceeding may show that any judgment, order or decree which is relevant under section 40, 41 or 42, and which has been proved by the adverse party, was delivered by a Court not competent to deliver it, or was obtained by fraud or collusion.
Cross_References: sec-40 (Refers to judgments relevant under S.40);; sec-41 (Refers to judgments relevant under S.41);; sec-42 (Refers to judgments relevant under S.42)