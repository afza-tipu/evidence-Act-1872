# FACTS WHICH NEED NOT BE PROVED

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: III
Section_ID: sec-58
Section_Number: 58
Section_Title: Facts admitted need not be proved
Status: Active
Tags: Proof, Admission
Section_Text: 58. No fact need be proved in any proceeding which the parties thereto or their agents agree to admit at the hearing, or which, before the hearing, they agree to admit by any writing under their hands, or which by any rule of pleading in force at the time they are deemed to have admitted by their pleadings:\n\nProvided that the Court may, in its discretion, require the facts admitted to be proved otherwise than by such admissions.
Provisos: PROV: Provided that the Court may, in its discretion, require the facts admitted to be proved otherwise than by such admissions.