# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-106
Section_Number: 106
Section_Title: Burden of proving fact especially within knowledge
Status: Active
Tags: Burden of Proof, Special Knowledge
Section_Text: 106. When any fact is especially within the knowledge of any person, the burden of proving that fact is upon him.\n\nIllustrations\n\n(a) When a person does an act with some intention other than that which the character and circumstances of the act suggest, the burden of proving that intention is upon him.\n\n(b) A is charged with traveling on a railway without a ticket. The burden of proving that he had a ticket is on him.
Illustrations: ILLUS: (a) When a person does an act with some intention other than that which the character and circumstances of the act suggest, the burden of proving that intention is upon him.\nILLUS: (b) A is charged with traveling on a railway without a ticket. The burden of proving that he had a ticket is on him.