# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-86
Section_Number: 86
Section_Title: Presumption as to certified copies of foreign judicial records
Status: Active
Tags: Presumption, May Presume, Foreign Judicial Record, Certified Copy
Section_Text: 86. The Court may presume that any document purporting to be a certified copy of any judicial record of any country not forming part of Bangladesh is genuine and accurate, if the document purports to be certified in any manner which is certified by any representative of the Government in or for such country to be the manner commonly in use in that country for the certification of copies of judicial records.\n\nSecond Paragraph.– [Omitted by the Bangladesh Laws (Revision And Declaration) Act, 1973 (Act No. VIII of 1973), section 3 and 2nd Schedule.]
Explanations: EXPL: [Omitted by the Bangladesh Laws (Revision And Declaration) Act, 1973 (Act No. VIII of 1973), section 3 and 2nd Schedule].
Amendments: Omission by Bangladesh Laws (Revision And Declaration) Act, 1973