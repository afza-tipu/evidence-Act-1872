# FACTS WHICH NEED NOT BE PROVED

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: III
Section_ID: sec-56
Section_Number: 56
Section_Title: Fact judicially noticeable need not be proved
Status: Active
Tags: Judicial Notice
Section_Text: 56. No fact of which the Court will take judicial notice need be proved
Cross_References: sec-57 (Relates to facts under S.57)