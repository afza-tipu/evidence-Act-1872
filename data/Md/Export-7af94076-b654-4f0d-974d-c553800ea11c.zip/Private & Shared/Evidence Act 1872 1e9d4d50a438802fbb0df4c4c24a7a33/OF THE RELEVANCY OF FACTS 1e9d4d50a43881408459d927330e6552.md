# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-16
Section_Number: 16
Section_Title: Existence of course of business when relevant
Status: Active
Tags: Relevancy Rule, Course of Business
Section_Text: 16. When there is a question whether a particular act was done, the existence of any course of business, according to which it naturally would have been done, is a relevant fact.\n\nIllustrations\n\n(a) The question is, whether a particular letter was dispatched.\n\nThe facts that it was the ordinary course of business for all letters put in a certain place to be carried to the post, and that that particular letter was put in that place are relevant.\n\n(b) The question is, whether particular letter reached A.\n\nThe facts that it was posted in due course, and was not returned through the Dead Letter office, are relevant.
Illustrations: ILLUS: (a) The question is, whether a particular letter was dispatched.\n\nThe facts that it was the ordinary course of business for all letters put in a certain place to be carried to the post, and that that particular letter was put in that place are relevant.\nILLUS: (b) The question is, whether particular letter reached A.\n\nThe facts that it was posted in due course, and was not returned through the Dead Letter office, are relevant.