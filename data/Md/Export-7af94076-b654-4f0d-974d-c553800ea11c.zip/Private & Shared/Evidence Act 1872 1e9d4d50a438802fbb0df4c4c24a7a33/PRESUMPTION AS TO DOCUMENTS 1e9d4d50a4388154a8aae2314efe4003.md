# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-81A
Section_Number: 81A
Section_Title: Presumption as to Gazettes in digital forms
Status: Active
Tags: Presumption, Shall Presume, Digital Record, Gazette, Proper Custody
Section_Text: ⁵⁴[81A.  The Court shall presume the genuineness of every digital record purporting to be the Official Gazette, or purporting to be digital record directed by any law to be kept by any person, if such digital record is kept substantially in the form required by law and is produced from proper custody.\n\nExplanation.-Digital records are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they naturally be; but no custody is improper if it is proved to have had a legitimate origin, or the circumstances of the particular case are such as to render such an origin probable.]
Explanations: EXPL: Digital records are said to be in proper custody if they are in the place in which, and under the care of the person with whom, they naturally be; but no custody is improper if it is proved to have had a legitimate origin, or the circumstances of the particular case are such as to render such an origin probable.
Amendments: Insertion by Evidence (Amendment) Act, 2022
Cross_References: sec-90 (Explanation similar to S.90);; sec-90A (Explanation similar to S.90A)