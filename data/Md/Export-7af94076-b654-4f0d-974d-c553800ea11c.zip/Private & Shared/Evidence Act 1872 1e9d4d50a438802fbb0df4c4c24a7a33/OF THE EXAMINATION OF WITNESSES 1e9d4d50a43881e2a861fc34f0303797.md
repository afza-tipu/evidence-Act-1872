# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-162
Section_Number: 162
Section_Title: Production of documents
Status: Active
Tags: Witness Examination, Production of Document, Admissibility, Judge's Role
Section_Text: 162. A witness summoned to produce a document shall, if it is in his possession or power, bring it to Court, notwithstanding any objection which there may be to its production or to its admissibility. The validity of any such objection shall be decided on by the Court.\n\nThe Court, if it sees fit, may inspect the document, unless it refers to matters of State, or take other evidence to enable it to determine on its admissibility.\nTranslation of documents\nIf for such a purpose it is necessary to cause any document to be translated, the Court may, if it thinks fit, direct the translator to keep the contents secret, unless the document is to be given in evidence: and, if the interpreter disobeys such direction, he shall be held to have committed an offence under section 166 of the ⁸⁶[* * *] Penal Code.