# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-140
Section_Number: 140
Section_Title: Witnesses to character
Status: Active
Tags: Witness Examination, Character Witness, Cross-examination, Re-examination
Section_Text: 140. Witnesses to character may be cross-examined and re-examined.