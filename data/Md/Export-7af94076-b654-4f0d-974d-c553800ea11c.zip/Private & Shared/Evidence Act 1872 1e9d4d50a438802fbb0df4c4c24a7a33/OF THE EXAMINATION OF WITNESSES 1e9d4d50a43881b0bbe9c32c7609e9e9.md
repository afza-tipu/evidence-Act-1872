# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-164
Section_Number: 164
Section_Title: Using, as evidence, of document production of which was refused on notice
Status: Active
Tags: Witness Examination, Production of Document, Notice to Produce, Refusal
Section_Text: 164. When a party refuses to produce a document which he has had notice to produce, he cannot afterwards use the document as evidence without the consent of the other party or the order of the Court.\n\nIllustration\n\nA sues B on an agreement and gives B notice to produce it. At the trail A calls for the document and B refuses to produce it. A gives secondary evidence of its contents. B seeks to produce the document itself to contradict the secondary evidence given by A, or in order to show that the agreement is not stamped. He cannot do so.
Illustrations: ILLUS: A sues B on an agreement and gives B notice to produce it. At the trail A calls for the document and B refuses to produce it. A gives secondary evidence of its contents. B seeks to produce the document itself to contradict the secondary evidence given by A, or in order to show that the agreement is not stamped. He cannot do so.