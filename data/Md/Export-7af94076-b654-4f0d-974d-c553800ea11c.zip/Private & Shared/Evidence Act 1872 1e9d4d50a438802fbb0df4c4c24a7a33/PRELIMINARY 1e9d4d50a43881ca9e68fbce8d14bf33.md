# PRELIMINARY

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: I
Section_ID: sec-3
Section_Number: 3
Section_Title: Interpretation-clause
Status: Active
Tags: Definition, Preliminary
Section_Text: 3. In this Act the following words and expressions are used in the following senses, unless a contrary intention appears from the context:-\n\n\Court\" includes all Judges and Magistrates and all persons
Definitions:  except arbitrators
Explanations:  legally authorized to take evidence.\n\n\"Fact\" means and includes-\n(1) anything
Illustrations:  state of things
Provisos:  or relation of things capable of being perceived by the senses;\n(2) any mental condition of which any person is conscious.\n\nIllustrations\n\n(a) That there are certain objects arranged in a certain order in a certain place
Amendments:  is a fact.\n\n(b) That a man heard or saw something
Cross_References:  is a fact.\n\n(c) That a man said certain words
:  is a fact.\n\n(d) That a man holds a certain opinion
 6:  is a fact.\n\nOne fact is said to be relevant to another when the one is connected with the other in any of the ways referred to in the provisions of this Act relating to the relevancy of facts.\nThe expression \"facts in issue\" means and includesany fact from which
 8:  the existence
 9:  non-existence
 10:  nature or extent of any right
 11:  liability
 12:  or disability
 13:  asserted or denied in any suit or proceeding
 14:  necessarily follows.\nExplanation.-Whenever
 15:  under the provisions of the law for the time being in force relating to Civil Procedure
 16:  any Court records an issue of fact
 18:  at the time of doing the act which caused B's death
 19:  was
 20:  by reason of unsoundness of mind
 21:  incapable of knowing its nature.\n\"Document\" means any matter expressed or described upon any substance by means of letters
 22:  figures or marks
 23:  or by more than one of those means
 24:  intended to be used
 25:  or which may be used
 26:  for the purpose of recording that matter ⁴[and includes any digital record].\nIllustrations\nA writing is a document:\nWords printed
 27:  lithographed or photographed are documents:\nA map or plan is a document:\nAn inscription on a metal plate or stone is a document:\nA caricature is a document.\n⁵[“Digital record\" or “electronic record” means any record
 28:  data or information generated
 29:  prepared
 30:  sent
 31:  received or stored in magnetic or electro-magnetic
 32:  optical
 33:  computer memory
 34:  micro film
 35:  computer generated micro fiche including audio
 36:  video
 37:  Digital Versatile Disc or Digital Video Disc (DVD)
 38:  records of Closed Circuit Television (CCTV)
 39:  drone data
 40:  records from cell phone
 41:  hardware
 42:  software or any other digital device as defined in Digital Security Act
 43:  2018 (Act No. 46 of 2018)];\n\"Evidence\" means and includes-\n(1) all statements which the Court permits or requires to be made before it by witnesses
 44:  in relation to matters of fact under inquiry:\nsuch statements are called oral evidence;\n(2) all documents produced for the inspection of the Court;\nsuch documents are called documentary evidence.\n⁶[(3) all materials or objects relating to blood
 45:  semen
 46:  hair
 47:  all body material
 48:  organ or part of organ
 49:  Deoxyribo Nucleic Acid (DNA)
 50:  finger impression
 51:  palm impression
 52:  iris impression and foot print or any other similar material or object which may-\n(i) establish that an offence has been committed or establish a link or relation between an offence and its victim or an offence and its offender; and\n(ii) prove or disprove a fact:\nsuch materials or objects are called physical or forensic evidence.]\n⁷[“Digital Signature\" or \"electronic Signature\" means any electronic signature as defined in Information and Communication Technology Act
 53:  2006 (Act No. 39 of 2006).\n“Digital Signature Certificate\" means any electronic signature certificate as defined in Information and Communication Technology Act
 54:  2006 (Act No. 39 of 2006).\n“Certifying Authority\" means Certificate Issuing Authority as defined in Information and Communication Technology Act
 55:  2006 (Act No. 39 of 2006).]\n\nA fact is said to be proved when
 56:  after considering the matters before it
 57:  the Court either believes it to exist
 58:  or considers its existence so probable that a prudent man ought
 59:  under the circumstances of the particular case
 60:  to act upon the supposition that it exists.\n\nA fact is said to be disproved when
 61:  after considering the matters before it
 62:  the Court either believes that it does not exist
 63:  or considers its non-existence so probable that a prudent man ought
 64:  under the circumstances of the particular case
 65:  to act upon the supposition that it does not exist.\n\nA fact is said not to be proved when it is neither proved nor disproved"
 66: DEF: Court: includes all Judges and Magistrates and all persons, except arbitrators, legally authorized to take evidence.\nDEF: Fact: means and includes-\n(1) anything, state of things, or relation of things capable of being perceived by the senses;\n(2) any mental condition of which any person is conscious.\nDEF: Relevant: One fact is said to be relevant to another when the one is connected with the other in any of the ways referred to in the provisions of this Act relating to the relevancy of facts.\nDEF: Facts in issue: The expression "facts in issue" means and includesany fact from which, either by itself or in connection with other facts, the existence, non-existence, nature or extent of any right, liability, or disability, asserted or denied in any suit or proceeding, necessarily follows.\nDEF: Document: means any matter expressed or described upon any substance by means of letters, figures or marks, or by more than one of those means, intended to be used, or which may be used, for the purpose of recording that matter ⁴[and includes any digital record].\nDEF: Digital record or electronic record: ⁵[“Digital record" or “electronic record” means any record, data or information generated, prepared, sent, received or stored in magnetic or electro-magnetic, optical, computer memory, micro film, computer generated micro fiche including audio, video, Digital Versatile Disc or Digital Video Disc (DVD), records of Closed Circuit Television (CCTV), drone data, records from cell phone, hardware, software or any other digital device as defined in Digital Security Act, 2018 (Act No. 46 of 2018)];\nDEF: Evidence: means and includes-\n(1) all statements which the Court permits or requires to be made before it by witnesses, in relation to matters of fact under inquiry:\nsuch statements are called oral evidence;\n(2) all documents produced for the inspection of the Court;\nsuch documents are called documentary evidence.\n⁶[(3) all materials or objects relating to blood, semen, hair, all body material, organ or part of organ, Deoxyribo Nucleic Acid (DNA), finger impression, palm impression, iris impression and foot print or any other similar material or object which may-\n(i) establish that an offence has been committed or establish a link or relation between an offence and its victim or an offence and its offender; and\n(ii) prove or disprove a fact:\nsuch materials or objects are called physical or forensic evidence.]\nDEF: Digital Signature or electronic Signature: ⁷[“Digital Signature" or "electronic Signature" means any electronic signature as defined in Information and Communication Technology Act, 2006 (Act No. 39 of 2006).\nDEF: Digital Signature Certificate: “Digital Signature Certificate" means any electronic signature certificate as defined in Information and Communication Technology Act, 2006 (Act No. 39 of 2006).\nDEF: Certifying Authority: “Certifying Authority" means Certificate Issuing Authority as defined in Information and Communication Technology Act, 2006 (Act No. 39 of 2006).]\nDEF: Proved: A fact is said to be proved when, after considering the matters before it, the Court either believes it to exist, or considers its existence so probable that a prudent man ought, under the circumstances of the particular case, to act upon the supposition that it exists.\nDEF: Disproved: A fact is said to be disproved when, after considering the matters before it, the Court either believes that it does not exist, or considers its non-existence so probable that a prudent man ought, under the circumstances of the particular case, to act upon the supposition that it does not exist.\nDEF: Not proved: A fact is said not to be proved when it is neither proved nor disproved
 67: EXPL: Whenever, under the provisions of the law for the time being in force relating to Civil Procedure, any Court records an issue of fact, the fact to be asserted or denied in the answer to such issue is a fact in issue.
 68: ILLUS: (a) That there are certain objects arranged in a certain order in a certain place, is a fact.\nILLUS: (b) That a man heard or saw something, is a fact.\nILLUS: (c) That a man said certain words, is a fact.\nILLUS: (d) That a man holds a certain opinion, has a certain intention, acts in good faith or fraudulently, or uses a particular word in a particular sense, or is or was at a specified time conscious of a particular sensation, is a fact.\nILLUS: (e) That a man has a certain reputation, is a fact.\nILLUS: A is accused of the murder of B.\nAt his trial the following facts may be in issue:–\nthat A caused B's death;\nthat A intended to cause B's death;\nthat A had received grave and sudden provocation from B;\nthat A, at the time of doing the act which caused B's death, was, by reason of unsoundness of mind, incapable of knowing its nature.\nILLUS: A writing is a document:\nWords printed, lithographed or photographed are documents:\nA map or plan is a document:\nAn inscription on a metal plate or stone is a document:\nA caricature is a document.
 70: Insertion by Evidence (Amendment) Act, 2022;; Insertion by Evidence (Amendment) Act, 2022;; Insertion by Evidence (Amendment) Act, 2022;; Insertion by Evidence (Amendment) Act, 2022