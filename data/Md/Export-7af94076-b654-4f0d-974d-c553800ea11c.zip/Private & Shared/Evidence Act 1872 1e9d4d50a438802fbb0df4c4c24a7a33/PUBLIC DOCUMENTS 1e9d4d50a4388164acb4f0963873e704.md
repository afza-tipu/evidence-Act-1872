# PUBLIC DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-74
Section_Number: 74
Section_Title: Public documents
Status: Active
Tags: Definition, Public Document
Section_Text: 74. The following documents are public documents:–\n\n(1) documents forming the acts or records of the acts-\n\n(i) of the sovereign authority,\n\n(ii) of official bodies and tribunals, and\n\n(iii) of public officers, legislative, judicial and executive of any part of Bangladesh or of the Commonwealth, or of a foreign country;\n\n(2) public records kept in Bangladesh of private documents.
Cross_References: sec-65 (Referenced by S.65(e))