# OF THE BURDEN OF PROOF

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: VII
Section_ID: sec-105
Section_Number: 105
Section_Title: Burden of proving that case of accused comes within exceptions
Status: Active
Tags: Burden of Proof, Criminal Defence, Exception
Section_Text: 105. When a person is accused of any offence, the burden of proving the existence of circumstances bringing the case within any of the General Exceptions in the ⁷⁰[* * *] Penal Code, or within any special exception or proviso contained in any other part of the same Code, or in any law defining the offence, is upon him, and the Court shall presume the absence of such circumstances.\n\nIllustrations\n\n(a) A, accused of murder, alleges that, by reason of unsoundness of mind, he did not know the nature of the act.\n\nThe burden of proof is on A.\n\n(b) A, accused of murder, alleges that, by grave and sudden provocation, he was deprived of the power of self-control.\n\nThe burden of proof is on A.\n\n(c) Section 325 of the ⁷¹[ * * *] Penal Code provides that whoever, except in the case provided for by section 335, voluntarily causes grievous hurt, shall be subject to certain punishments.\n\nA is charged with voluntarily causing grievous hurt under section 325.\n\nThe burden of proving the circumstances bringing the case under section 335 lies on A.
Illustrations: ILLUS: (a) A, accused of murder, alleges that, by reason of unsoundness of mind, he did not know the nature of the act.\n\nThe burden of proof is on A.\nILLUS: (b) A, accused of murder, alleges that, by grave and sudden provocation, he was deprived of the power of self-control.\n\nThe burden of proof is on A.\nILLUS: (c) Section 325 of the ⁷¹[ * * *] Penal Code provides that whoever, except in the case provided for by section 335, voluntarily causes grievous hurt, shall be subject to certain punishments.\n\nA is charged with voluntarily causing grievous hurt under section 325.\n\nThe burden of proving the circumstances bringing the case under section 335 lies on A.
Amendments: Omission by Bangladesh Laws (Revision And Declaration) Act, 1973;; Omission by Bangladesh Laws (Revision And Declaration) Act, 1973