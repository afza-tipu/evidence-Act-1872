# OF THE RELEVANCY OF FACTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-13
Section_Number: 13
Section_Title: Facts relevant when right or custom is in question
Status: Active
Tags: Relevancy Rule, Right, Custom, Transaction, Instances
Section_Text: 13. Where the question is as to the existence of any right of custom, the following facts are relevant:–\n\n(a) any transaction by which the right or custom in question was created, claimed, modified, recognized, asserted or denied, or which was inconsistent with its existence;\n\n(b) particular instances in which the right or custom was claimed, recognized or exercised, or in which its exercise was disputed, asserted or departed from.\n\nIllustration\n\nThe question is whether A has a right to a fishery. A deed conferring the fishery on A's ancestors, a mortgage of the fishery by A's father, a subsequent grant of the fishery by A's father, irreconcilable with the mortgage, particular instances in which A's father exercised the right, or in which the exercise of the right was stopped by A's neighbours, are relevant facts.
Illustrations: ILLUS: The question is whether A has a right to a fishery. A deed conferring the fishery on A's ancestors, a mortgage of the fishery by A's father, a subsequent grant of the fishery by A's father, irreconcilable with the mortgage, particular instances in which A's father exercised the right, or in which the exercise of the right was stopped by A's neighbours, are relevant facts.
Cross_References: sec-32 (S.32(7) refers to S.13(a))