# sec-132 (Relates to self-incrimination);; sec-147 (Referenced by S.147);; sec-148 (Referenced by S.148)

Chapter_Number: 2022, Substitution by Evidence (Amendment) Act