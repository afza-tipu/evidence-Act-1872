# JUDGMENTS OF COURTS OF JUSTICE WHEN RELEVANT

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-41
Section_Number: 41
Section_Title: Relevancy of certain judgments in probate, etc., jurisdiction
Status: Active
Tags: Relevancy, Judgment, In Rem, Probate, Matrimonial, Admiralty, Insolvency
Section_Text: 41. A final judgment, order or decree of a competent Court, in the exercise of probate, matrimonial, admiralty or insolvency jurisdiction, which confers upon or takes away from any person any legal character, or which declares any person to be entitled to any such character, or to be entitled to any specific thing, not as against any specified person but absolutely, is relevant when the existence of any such legal character, or the title of any such person to any such thing, is relevant.\n\nSuch judgment, order or decree is conclusive proof-\n\nthat any legal character which it confers accrued at the time when such judgment, order or decree come into operation;\n\nthat any legal character, to which it declares any such person to be entitled, accrued to that person at the time when such judgment, order or decree declares it to have accrued to that person;\n\nthat any legal character which it takes away from any such person ceased at the time from which such judgment, order or decree declared that it had ceased or should cease;\n\nand that anything to which it declares any person to be so entitled was the property of that person at the time from which such judgment, order or decree declares that it had been or should be his property.
Cross_References: sec-43 (Referenced by S.43);; sec-44 (Referenced by S.44)