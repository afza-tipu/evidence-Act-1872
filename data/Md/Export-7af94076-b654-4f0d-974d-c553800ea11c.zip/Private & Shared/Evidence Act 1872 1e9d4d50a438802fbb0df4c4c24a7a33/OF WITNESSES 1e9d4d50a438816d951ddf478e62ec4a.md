# OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: IX
Section_ID: sec-121
Section_Number: 121
Section_Title: Judges and Magistrates
Status: Active
Tags: Witness Rule, Privilege, Judge, Magistrate
Section_Text: 121. No Judge or Magistrate shall, except upon the special order of some Court to which he is subordinate, be compelled to answer any questions as to his own conduct in Court as such Judge and Magistrate, or as to anything which came to his knowledge in Court as such Judge or Magistrate: but he may be examined as to other matters which occurred in his presence whilst he was so acting.\n\nIllustrations\n\n(a) A, on his trial before the Court of Session, says that a deposition was improperly taken by B, the Magistrate. B cannot be compelled to answer questions as to this, except upon the special order of a superior Court.\n\n(b) A is accused before the Court of Session of having given false evidence before B, a Magistrate. B cannot be asked what A said, except upon the special order of the superior Court.\n\n(c) A is accused before the Court of Session of attempting to murder a police-officer whilst on his trail before B, a Sessions Judge. B may be examined as to what occurred.
Illustrations: ILLUS: (a) A, on his trial before the Court of Session, says that a deposition was improperly taken by B, the Magistrate. B cannot be compelled to answer questions as to this, except upon the special order of a superior Court.\nILLUS: (b) A is accused before the Court of Session of having given false evidence before B, a Magistrate. B cannot be asked what A said, except upon the special order of the superior Court.\nILLUS: (c) A is accused before the Court of Session of attempting to murder a police-officer whilst on his trail before B, a Sessions Judge. B may be examined as to what occurred.
Cross_References: sec-165 (Privilege referred to in S.165)