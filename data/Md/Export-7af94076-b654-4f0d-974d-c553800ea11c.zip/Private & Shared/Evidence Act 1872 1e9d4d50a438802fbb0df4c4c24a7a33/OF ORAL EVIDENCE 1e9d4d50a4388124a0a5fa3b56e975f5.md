# OF ORAL EVIDENCE

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: IV
Section_ID: sec-59
Section_Number: 59
Section_Title: Proof of facts by oral evidence
Status: Active
Tags: Oral Evidence, Proof
Section_Text: 59. All facts, except the contents of documents, may be proved by oral evidence.