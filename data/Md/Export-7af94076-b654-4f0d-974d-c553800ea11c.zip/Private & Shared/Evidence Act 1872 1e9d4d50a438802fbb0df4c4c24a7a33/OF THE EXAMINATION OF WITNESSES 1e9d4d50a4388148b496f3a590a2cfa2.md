# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-149
Section_Number: 149
Section_Title: Question not to be asked without reasonable grounds
Status: Active
Tags: Witness Examination, Cross-examination, Credit
Section_Text: 149. No such question as is referred to in section 148 ought to be asked, unless the person asking it has reasonable grounds for thinking that the imputation which it conveys is well-founded.\n\nIllustrations\n\n(a) An ⁷⁸[advocate] is instructed by a ⁷⁹[client] that an important witness is a dakait. This is a reasonable ground for asking the witness whether he is a dakait.\n\n(b) A pleader is informed by a person in Court that an important witness is a dakait. The informant, on being questioned by the pleader, gives satisfactory reasons for his statement. This is a reasonable ground for asking the witness whether he is a dakait.\n\n(c) A witness, of whom nothing whatever is known, is asked at random whether he is a dakait. There are here no reasonable grounds for the question.\n\n(d) A witness, of whom nothing whatever is known, being questioned as to his mode of life and means of living, gives unsatisfactory answers. This may be a reasonable ground for asking him if he is a dakait.
Illustrations: ILLUS: (a) An ⁷⁸[advocate] is instructed by a ⁷⁹[client] that an important witness is a dakait. This is a reasonable ground for asking the witness whether he is a dakait.\nILLUS: (b) A pleader is informed by a person in Court that an important witness is a dakait. The informant, on being questioned by the pleader, gives satisfactory reasons for his statement. This is a reasonable ground for asking the witness whether he is a dakait.\nILLUS: (c) A witness, of whom nothing whatever is known, is asked at random whether he is a dakait. There are here no reasonable grounds for the question.\nILLUS: (d) A witness, of whom nothing whatever is known, being questioned as to his mode of life and means of living, gives unsatisfactory answers. This may be a reasonable ground for asking him if he is a dakait.
Amendments: Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973;; Substitution by Bangladesh Laws (Revision And Declaration) Act, 1973
Cross_References: sec-148 (Refers to questions under S.148);; sec-150 (Consequences under S.150 if violated);; sec-165 (Judge's power limited by this section)