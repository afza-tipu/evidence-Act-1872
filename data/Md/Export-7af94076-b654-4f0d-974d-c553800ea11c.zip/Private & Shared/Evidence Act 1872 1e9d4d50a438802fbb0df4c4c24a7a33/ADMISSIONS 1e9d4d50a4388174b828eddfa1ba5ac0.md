# ADMISSIONS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: I
Part_Title: RELEVANCY OF FACTS
Chapter_Number: II
Section_ID: sec-24
Section_Number: 24
Section_Title: Confession caused by inducement, threat or promise, when irrelevant in criminal proceeding
Status: Active
Tags: Confession Rule, Involuntary Confession, Inducement, Threat, Promise
Section_Text: 24. A confession made by an accused person is irrelevant in a criminal proceeding, if the making of the confession appears to the Court to have been caused by any inducement, threat or promise having reference to the charge against the accused person, proceeding from a person in authority and sufficient, in the opinion of the Court, to give the accused person grounds which would appear to him reasonable for supposing that by making it he would gain any advantage or avoid any evil of a temporal nature in reference to the proceedings against him.
Cross_References: sec-28 (Relates to S.28);; sec-29 (Relates to S.29)