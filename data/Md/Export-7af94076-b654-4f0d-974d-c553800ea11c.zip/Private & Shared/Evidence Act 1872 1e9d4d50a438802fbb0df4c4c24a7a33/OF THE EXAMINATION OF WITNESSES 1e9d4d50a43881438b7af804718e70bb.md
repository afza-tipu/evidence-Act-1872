# OF THE EXAMINATION OF WITNESSES

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: III
Part_Title: PRODUCTION AND EFFECT OF EVIDENCE
Chapter_Number: X
Section_ID: sec-137
Section_Number: 137
Section_Title: Examination-in-chief
Status: Active
Tags: Witness Examination, Examination-in-chief, Cross-examination, Re-examination
Section_Text: 137. The examination of a witness by the party who calls him shall be called his examination-in-chief.\nCross-examination\nThe examination of a witness by the adverse party shall be called his cross-examination.\nRe-examination\nThe examination of a witness, subsequent to the cross-examination by the party who called him, shall be called his re-examination.
Cross_References: sec-138 (Order of examinations under S.138)