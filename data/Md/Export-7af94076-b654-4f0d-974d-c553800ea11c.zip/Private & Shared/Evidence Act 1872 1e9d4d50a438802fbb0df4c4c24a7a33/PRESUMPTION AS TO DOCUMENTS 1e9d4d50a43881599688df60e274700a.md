# PRESUMPTION AS TO DOCUMENTS

Act_ID: evidence-act-1872-bd
Act_Title: 1872, The Evidence Act
Part_Number: II
Part_Title: ON PROOF
Chapter_Number: V
Section_ID: sec-83
Section_Number: 83
Section_Title: Presumption as to maps or plans made by authority of Government
Status: Active
Tags: Presumption, Shall Presume, Maps, Plans, Government Authority
Section_Text: 83. The Court shall presume that maps or plans purporting to be made by the authority of the Government were so made, and are accurate; but maps or plans made for the purposes of any cause must be proved to be accurate.